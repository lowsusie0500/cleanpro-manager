import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding CleanPro database...')

  // ── Settings ──────────────────────────────────────────
  await prisma.setting.createMany({
    skipDuplicates: true,
    data: [
      { key: 'company_name', value: 'CleanPro Services' },
      { key: 'company_phone', value: '+60 12-345 6789' },
      { key: 'company_address', value: 'Klang, Selangor, Malaysia' },
      { key: 'company_ssm', value: 'SA0012345-X' },
      { key: 'currency', value: 'RM' },
      { key: 'language', value: 'en' },
      { key: 'invoice_prefix', value: 'INV' },
      { key: 'quote_prefix', value: 'QT' },
    ],
  })

  // ── Staff ─────────────────────────────────────────────
  const staffData = [
    { name: 'Kokoy', phone: '+60 12-111 2233', role: 'cleaner', area: 'Telok Gadong / Port Klang', colorCode: 'teal' },
    { name: 'Santi', phone: '+60 12-222 3344', role: 'cleaner', area: 'Teluk Pulai', colorCode: 'amber' },
    { name: 'Suci', phone: '+60 12-333 4455', role: 'cleaner', area: 'Tmn Klang Jaya', colorCode: 'green' },
    { name: 'Rika', phone: '+60 12-444 5566', role: 'cleaner', area: 'Telok Gadong', colorCode: 'purple' },
    { name: 'Maria', phone: '+60 12-555 6677', role: 'cleaner', area: 'Bukit Tinggi / Teluk Pulai', colorCode: 'pink' },
    { name: 'Coco', phone: '+60 12-666 7788', role: 'driver', area: 'Sri Andalas', colorCode: 'blue' },
    { name: 'Yuli 44', phone: '+60 12-777 8899', role: 'cleaner', area: 'Botanic / Bukit Tinggi', colorCode: 'teal' },
    { name: 'Wiwi', phone: '+60 12-888 9900', role: 'cleaner', area: 'Bukit Tinggi', colorCode: 'amber' },
    { name: 'Heni (Jawa)', phone: '+60 12-999 0011', role: 'cleaner', area: 'Tmn Sentosa', colorCode: 'green' },
    { name: 'Tina (Jawa)', phone: '+60 12-100 0122', role: 'cleaner', area: 'Alam Impian / Anggerik', colorCode: 'purple' },
    { name: 'Jay', phone: '+60 12-110 0233', role: 'driver', area: 'Sek 19', colorCode: 'pink' },
  ]

  const staff: Record<string, any> = {}
  for (const s of staffData) {
    const created = await prisma.staff.upsert({
      where: { id: s.name.toLowerCase().replace(/\s+/g, '-') },
      update: {},
      create: { id: s.name.toLowerCase().replace(/\s+/g, '-'), ...s },
    })
    staff[s.name] = created
  }

  // ── Admin User ─────────────────────────────────────────
  const adminPass = await bcrypt.hash('admin123', 10)
  await prisma.user.upsert({
    where: { email: 'admin@cleanpro.com' },
    update: {},
    create: { name: 'Admin', email: 'admin@cleanpro.com', password: adminPass, role: 'admin' },
  })

  // Supervisor Kay
  const kayPass = await bcrypt.hash('kay123', 10)
  await prisma.user.upsert({
    where: { email: 'kay@cleanpro.com' },
    update: {},
    create: { name: 'Kay', email: 'kay@cleanpro.com', password: kayPass, role: 'supervisor' },
  })

  // ── Clients ────────────────────────────────────────────
  const clientsData = [
    { name: 'MDM ONG', phone: '+60 11-1234 5678', address: 'Jalan Telok Gadong, Klang', area: 'Telok Gadong', frequency: 'weekly', assignedStaffId: staff['Kokoy']?.id },
    { name: 'MS FONG', phone: '+60 11-2345 6789', address: 'Jalan Teluk Pulai, Klang', area: 'Teluk Pulai', frequency: 'weekly', assignedStaffId: staff['Santi']?.id },
    { name: 'HEMELA', phone: '+60 11-3456 7890', address: 'Tmn Klang Jaya, Klang', area: 'Tmn Klang Jaya', frequency: 'biweekly', assignedStaffId: staff['Suci']?.id },
    { name: 'KAMALAKARAN', phone: '+60 11-4567 8901', address: 'Jalan Telok Gadong, Klang', area: 'Telok Gadong', frequency: 'weekly', assignedStaffId: staff['Rika']?.id },
    { name: 'ANG MOH ENGLISH', phone: '+60 11-5678 9012', address: 'Bukit Tinggi, Klang', area: 'Bukit Tinggi', frequency: 'weekly', assignedStaffId: staff['Maria']?.id },
    { name: 'MR CHAW', phone: '+60 11-6789 0123', address: 'Teluk Pulai, Klang', area: 'Teluk Pulai', frequency: 'weekly', assignedStaffId: staff['Maria']?.id },
    { name: 'MS SUBA', phone: '+60 11-7890 1234', address: 'Sri Andalas, Klang', area: 'Sri Andalas', frequency: 'monthly', assignedStaffId: staff['Coco']?.id },
    { name: 'MONA', phone: '+60 11-8901 2345', address: 'Akasia Apt, Botanic, Klang', area: 'Botanic', frequency: 'weekly', assignedStaffId: staff['Yuli 44']?.id },
    { name: 'PRECISION', phone: '+60 11-9012 3456', address: 'Port Klang, Selangor', area: 'Port Klang', frequency: 'monthly', assignedStaffId: staff['Kokoy']?.id },
    { name: 'JENNY THAM', phone: '+60 11-0123 4567', address: 'Alam Impian, Shah Alam', area: 'Alam Impian', frequency: 'biweekly', assignedStaffId: staff['Tina (Jawa)']?.id },
    { name: 'MDM UMAH', phone: '+60 11-1234 0001', address: 'Bukit Tinggi, Klang', area: 'Bukit Tinggi', frequency: 'weekly', assignedStaffId: staff['Wiwi']?.id },
    { name: 'HUEY PENG', phone: '+60 11-2345 0002', address: 'Tmn Sentosa, Klang', area: 'Tmn Sentosa', frequency: 'weekly', assignedStaffId: staff['Heni (Jawa)']?.id },
    { name: 'ESMEE COUTURE', phone: '+60 11-3456 0003', address: 'Anggerik, Klang', area: 'Anggerik', frequency: 'biweekly', assignedStaffId: staff['Tina (Jawa)']?.id },
    { name: 'KANAGA KANNATHASAN', phone: '+60 11-4567 0004', address: 'Seksyen 19, Shah Alam', area: 'Sek 19', frequency: 'weekly', assignedStaffId: staff['Jay']?.id },
    { name: 'MS SARA', phone: '+60 11-5678 0005', address: 'Bukit Tinggi, Klang', area: 'Bukit Tinggi', frequency: 'weekly', assignedStaffId: staff['Yuli 44']?.id },
    { name: 'IVAN', phone: '+60 11-6789 0006', address: 'Bukit Tinggi, Klang', area: 'Bukit Tinggi', frequency: 'weekly', assignedStaffId: staff['Wiwi']?.id },
  ]

  const clients: Record<string, any> = {}
  for (const c of clientsData) {
    const created = await prisma.client.create({ data: c })
    clients[c.name] = created
  }

  // ── Jobs (Monday = this week) ──────────────────────────
  const monday = getMonday(new Date())
  const tuesday = new Date(monday); tuesday.setDate(monday.getDate() + 1)

  const jobsData = [
    { clientName: 'MDM ONG', staffName: 'Kokoy', date: monday, startTime: '08:00', endTime: '12:00' },
    { clientName: 'PRECISION', staffName: 'Kokoy', date: monday, startTime: '13:30', endTime: '17:30' },
    { clientName: 'MS FONG', staffName: 'Santi', date: monday, startTime: '08:00', endTime: '13:00' },
    { clientName: 'HEMELA', staffName: 'Suci', date: monday, startTime: '08:00', endTime: '12:00' },
    { clientName: 'KAMALAKARAN', staffName: 'Rika', date: monday, startTime: '09:00', endTime: '12:00' },
    { clientName: 'ANG MOH ENGLISH', staffName: 'Maria', date: monday, startTime: '09:00', endTime: '12:00' },
    { clientName: 'MR CHAW', staffName: 'Maria', date: monday, startTime: '14:00', endTime: '18:00' },
    { clientName: 'MS SUBA', staffName: 'Coco', date: monday, startTime: '09:00', endTime: '13:00' },
    { clientName: 'MONA', staffName: 'Yuli 44', date: tuesday, startTime: '08:00', endTime: '12:00' },
    { clientName: 'MS SARA', staffName: 'Yuli 44', date: tuesday, startTime: '13:00', endTime: '18:00' },
    { clientName: 'MDM UMAH', staffName: 'Wiwi', date: tuesday, startTime: '08:30', endTime: '12:30' },
    { clientName: 'IVAN', staffName: 'Wiwi', date: tuesday, startTime: '13:00', endTime: '17:00' },
    { clientName: 'HUEY PENG', staffName: 'Heni (Jawa)', date: tuesday, startTime: '08:00', endTime: '12:00' },
    { clientName: 'JENNY THAM', staffName: 'Tina (Jawa)', date: tuesday, startTime: '08:30', endTime: '12:30' },
    { clientName: 'ESMEE COUTURE', staffName: 'Tina (Jawa)', date: tuesday, startTime: '13:30', endTime: '15:30' },
    { clientName: 'KANAGA KANNATHASAN', staffName: 'Jay', date: tuesday, startTime: '09:00', endTime: '13:00' },
  ]

  for (const j of jobsData) {
    const client = clients[j.clientName]
    const staffMember = staff[j.staffName]
    if (client && staffMember) {
      await prisma.job.create({
        data: {
          clientId: client.id,
          staffId: staffMember.id,
          date: j.date,
          startTime: j.startTime,
          endTime: j.endTime,
          frequency: 'weekly',
          status: 'scheduled',
        },
      })
    }
  }

  // ── Invoices ───────────────────────────────────────────
  const invoiceItems = [
    { client: 'MDM ONG', num: 'INV-001', amount: 350, status: 'paid', daysAgo: 30 },
    { client: 'MS FONG', num: 'INV-002', amount: 280, status: 'paid', daysAgo: 28 },
    { client: 'HEMELA', num: 'INV-003', amount: 420, status: 'pending', daysAgo: 10 },
    { client: 'KAMALAKARAN', num: 'INV-004', amount: 310, status: 'overdue', daysAgo: 35 },
    { client: 'ANG MOH ENGLISH', num: 'INV-005', amount: 500, status: 'pending', daysAgo: 5 },
    { client: 'PRECISION', num: 'INV-006', amount: 1200, status: 'pending', daysAgo: 3 },
  ]

  for (const inv of invoiceItems) {
    const client = clients[inv.client]
    if (!client) continue
    const issueDate = new Date(); issueDate.setDate(issueDate.getDate() - inv.daysAgo)
    const dueDate = new Date(issueDate); dueDate.setDate(issueDate.getDate() + 14)
    const created = await prisma.invoice.create({
      data: {
        number: inv.num,
        clientId: client.id,
        issueDate,
        dueDate,
        subtotal: inv.amount,
        tax: 0,
        total: inv.amount,
        status: inv.status,
        notes: 'Regular cleaning service',
      },
    })
    await prisma.invoiceItem.create({
      data: {
        invoiceId: created.id,
        description: 'Regular cleaning service',
        quantity: 1,
        unitPrice: inv.amount,
        total: inv.amount,
      },
    })
  }

  // ── Quotes ─────────────────────────────────────────────
  await prisma.quote.createMany({
    data: [
      { number: 'QT-001', clientName: "Mrs. Lim", clientPhone: '+60 12-111 0001', serviceType: 'Deep Cleaning', propertySize: 1500, amount: 450, status: 'accepted', validUntil: new Date(Date.now() + 7 * 86400000) },
      { number: 'QT-002', clientName: "Mr. Kumar", clientPhone: '+60 12-222 0002', serviceType: 'Regular Cleaning', propertySize: 1200, amount: 300, status: 'pending', validUntil: new Date(Date.now() + 7 * 86400000) },
      { number: 'QT-003', clientName: "Puan Aishah", clientPhone: '+60 12-333 0003', serviceType: 'Post-renovation', propertySize: 2000, amount: 800, status: 'pending', validUntil: new Date(Date.now() + 7 * 86400000) },
      { number: 'QT-004', clientName: "Mr. Chong", clientPhone: '+60 12-444 0004', serviceType: 'Office Cleaning', amount: 650, status: 'rejected' },
      { number: 'QT-005', clientName: "Mrs. Sharma", clientPhone: '+60 12-555 0005', serviceType: 'Move-in Clean', amount: 380, status: 'accepted', validUntil: new Date(Date.now() + 7 * 86400000) },
    ],
  })

  // ── Payments ───────────────────────────────────────────
  const inv001 = await prisma.invoice.findFirst({ where: { number: 'INV-001' } })
  const inv002 = await prisma.invoice.findFirst({ where: { number: 'INV-002' } })
  if (inv001 && clients['MDM ONG']) {
    await prisma.payment.create({ data: { invoiceId: inv001.id, clientId: clients['MDM ONG'].id, amount: 350, method: 'cash', date: new Date(Date.now() - 2 * 86400000) } })
  }
  if (inv002 && clients['MS FONG']) {
    await prisma.payment.create({ data: { invoiceId: inv002.id, clientId: clients['MS FONG'].id, amount: 280, method: 'bank_transfer', date: new Date(Date.now() - 1 * 86400000) } })
  }

  // ── Expenses ───────────────────────────────────────────
  await prisma.expense.createMany({
    data: [
      { staffId: staff['Kokoy']?.id, category: 'fuel', description: 'Petrol for van (Wira)', amount: 80, date: new Date(Date.now() - 3 * 86400000) },
      { staffId: staff['Santi']?.id, category: 'supplies', description: 'Cleaning chemicals – Kementeria', amount: 145, date: new Date(Date.now() - 2 * 86400000) },
      { staffId: staff['Maria']?.id, category: 'equipment', description: 'Mop replacement x3', amount: 65, date: new Date(Date.now() - 1 * 86400000) },
      { staffId: staff['Jay']?.id, category: 'fuel', description: 'Petrol for van (Myvi)', amount: 60, date: new Date() },
    ],
  })

  // ── Daily Reports ──────────────────────────────────────
  if (staff['Kokoy'] && staff['Maria']) {
    await prisma.dailyReport.createMany({
      data: [
        { staffId: staff['Kokoy'].id, date: new Date(), clientName: 'MDM ONG', cashReceived: 350, notes: 'All done, client happy', submitted: true },
        { staffId: staff['Maria'].id, date: new Date(), clientName: 'MR CHAW', cashReceived: 420, notes: 'Client requested extra kitchen cleaning', submitted: true },
      ],
    })
  }

  console.log('✅ Seeding complete!')
  console.log('🔑 Login: admin@cleanpro.com / admin123')
}

function getMonday(d: Date) {
  const day = d.getDay()
  const diff = d.getDate() - day + (day === 0 ? -6 : 1)
  const monday = new Date(d)
  monday.setDate(diff)
  monday.setHours(0, 0, 0, 0)
  return monday
}

main()
  .catch(console.error)
  .finally(async () => { await prisma.$disconnect() })
