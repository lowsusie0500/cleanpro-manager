export type Lang = 'en' | 'zh'

export const translations: Record<string, Record<Lang, string>> = {
  // Nav
  dashboard:       { en: 'Dashboard',         zh: '仪表板' },
  schedule:        { en: 'Schedule',           zh: '排班表' },
  dailyReport:     { en: 'Daily Report',       zh: '每日报告' },
  clients:         { en: 'Clients',            zh: '客户管理' },
  employees:       { en: 'Staff / Drivers',    zh: '员工/司机' },
  quotes:          { en: 'Quotes',             zh: '报价单' },
  invoices:        { en: 'Invoices',           zh: '发票管理' },
  payments:        { en: 'Payments',           zh: '付款方式' },
  expenses:        { en: 'Expenses',           zh: '费用记录' },
  settings:        { en: 'Settings',           zh: '设置' },
  // Actions
  addJob:          { en: 'Add Job',            zh: '新增工作' },
  addClient:       { en: 'Add Client',         zh: '新增客户' },
  addStaff:        { en: 'Add Staff',          zh: '新增员工' },
  viewSchedule:    { en: 'View Schedule',      zh: '查看排班' },
  viewAll:         { en: 'View All',           zh: '查看全部' },
  export:          { en: 'Export',             zh: '导出' },
  today:           { en: 'Today',              zh: '今天' },
  save:            { en: 'Save',               zh: '保存' },
  cancel:          { en: 'Cancel',             zh: '取消' },
  delete:          { en: 'Delete',             zh: '删除' },
  edit:            { en: 'Edit',               zh: '编辑' },
  signIn:          { en: 'Sign In',            zh: '登录' },
  signOut:         { en: 'Sign Out',           zh: '退出' },
  // Fields
  name:            { en: 'Name',               zh: '姓名' },
  role:            { en: 'Role',               zh: '职位' },
  area:            { en: 'Area',               zh: '地区' },
  status:          { en: 'Status',             zh: '状态' },
  actions:         { en: 'Actions',            zh: '操作' },
  frequency:       { en: 'Frequency',          zh: '频率' },
  date:            { en: 'Date',               zh: '日期' },
  driver:          { en: 'Driver / Staff',     zh: '司机/员工' },
  cashReceived:    { en: 'Cash Received (RM)', zh: '收到现金 (RM)' },
  notes:           { en: 'Notes',              zh: '备注' },
  // Dashboard
  todayJobs:       { en: "Today's Jobs",       zh: '今日工作' },
  monthlyRev:      { en: 'Monthly Revenue',    zh: '本月收入' },
  activeClients:   { en: 'Active Clients',     zh: '活跃客户' },
  pendingInvoices: { en: 'Pending Invoices',   zh: '待付发票' },
  todaySchedule:   { en: "Today's Schedule",   zh: '今日排班' },
  recentActivity:  { en: 'Recent Activity',    zh: '最近动态' },
  // Report
  uploadExpenses:  { en: 'Upload Expense Receipts', zh: '上传费用收据' },
  tapToUpload:     { en: 'Tap to upload photos',    zh: '点击上传照片' },
  submitReport:    { en: 'Submit Report',       zh: '提交报告' },
  recentReports:   { en: 'Recent Reports',     zh: '最近报告' },
  report:          { en: 'Report',             zh: '报告' },
  // Auth
  email:           { en: 'Email',              zh: '邮箱' },
  password:        { en: 'Password',           zh: '密码' },
  invalidCredentials: { en: 'Invalid email or password', zh: '邮箱或密码错误' },
}

export function t(key: string, lang: Lang = 'en'): string {
  return translations[key]?.[lang] ?? translations[key]?.en ?? key
}
