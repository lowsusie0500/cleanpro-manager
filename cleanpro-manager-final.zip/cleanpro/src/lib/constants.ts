export const STAFF_COLORS: Record<string, string> = {
  teal:   '#0F4C5C',
  amber:  '#F0A500',
  green:  '#38A169',
  purple: '#805AD5',
  pink:   '#D53F8C',
  blue:   '#3182CE',
}

export const COLOR_CLASSES: Record<string, string> = {
  teal:   'sch-block-teal',
  amber:  'sch-block-amber',
  green:  'sch-block-green',
  purple: 'sch-block-purple',
  pink:   'sch-block-pink',
  blue:   'sch-block-blue',
}

export const COLOR_OPTIONS = [
  { value: 'teal',   label: 'Teal' },
  { value: 'amber',  label: 'Amber' },
  { value: 'green',  label: 'Green' },
  { value: 'purple', label: 'Purple' },
  { value: 'pink',   label: 'Pink' },
  { value: 'blue',   label: 'Blue' },
]

export const PAYMENT_METHODS = [
  { value: 'cash',          label: 'Cash',          icon: '💵' },
  { value: 'bank_transfer', label: 'Bank Transfer',  icon: '🏦' },
  { value: 'tng',           label: 'TNG eWallet',    icon: '📱' },
  { value: 'duitnow',       label: 'DuitNow QR',     icon: '📲' },
  { value: 'card',          label: 'Credit/Debit',   icon: '💳' },
]

export const EXPENSE_CATEGORIES = [
  { value: 'fuel',      label: 'Fuel',              icon: '⛽' },
  { value: 'supplies',  label: 'Cleaning Supplies',  icon: '🧴' },
  { value: 'equipment', label: 'Equipment',          icon: '🔧' },
  { value: 'transport', label: 'Transport',          icon: '🚗' },
  { value: 'misc',      label: 'Miscellaneous',      icon: '📦' },
]

export const SERVICE_TYPES = [
  'Regular Cleaning',
  'Deep Cleaning',
  'Post-renovation Cleaning',
  'Move-in / Move-out Cleaning',
  'Office Cleaning',
  'Carpet Cleaning',
  'Window Cleaning',
]

export const FREQUENCY_OPTIONS = [
  { value: 'once',      label: 'One-time' },
  { value: 'weekly',    label: 'Weekly' },
  { value: 'biweekly',  label: 'Bi-Weekly' },
  { value: 'monthly',   label: 'Monthly' },
]
