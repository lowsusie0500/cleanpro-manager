'use client'

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const DEMO_DATA = [
  { month: 'Jan', revenue: 18200, expenses: 3100 },
  { month: 'Feb', revenue: 21500, expenses: 2800 },
  { month: 'Mar', revenue: 19800, expenses: 3400 },
  { month: 'Apr', revenue: 24500, expenses: 2900 },
  { month: 'May', revenue: 22100, expenses: 3200 },
  { month: 'Jun', revenue: 26800, expenses: 3600 },
]

export function RevenueChart() {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={DEMO_DATA} margin={{ top: 4, right: 4, left: -10, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#9CA3AF' }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 12, fill: '#9CA3AF' }} axisLine={false} tickLine={false}
          tickFormatter={v => `RM${(v / 1000).toFixed(0)}k`} />
        <Tooltip
          formatter={(val, name) => [`RM ${Number(val).toLocaleString()}`, name === 'revenue' ? 'Revenue' : 'Expenses']}
          contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12 }}
        />
        <Bar dataKey="revenue" fill="#0F4C5C" radius={[4, 4, 0, 0]} />
        <Bar dataKey="expenses" fill="#F0A500" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}
