'use client'

import { format } from 'date-fns'
import { useLanguageStore } from '@/store/languageStore'

interface Props {
  invoice: any
  onClose: () => void
}

export function InvoicePreview({ invoice, onClose }: Props) {
  const { lang } = useLanguageStore()

  function handlePrint() {
    window.print()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl max-h-[92vh] overflow-y-auto">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 no-print">
          <h2 className="font-bold text-gray-800">Invoice Preview</h2>
          <div className="flex gap-2">
            <button onClick={handlePrint}
              className="px-4 py-2 bg-[#0F4C5C] text-white text-sm font-semibold rounded-lg hover:bg-[#1a6b80] transition-colors">
              🖨️ Print / PDF
            </button>
            <button onClick={onClose}
              className="px-4 py-2 border border-gray-200 text-sm font-medium rounded-lg hover:border-gray-400 transition-colors">
              Close
            </button>
          </div>
        </div>

        {/* Invoice body */}
        <div className="p-8" id="invoice-content">
          {/* Header */}
          <div className="flex justify-between items-start mb-8">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-10 h-10 rounded-xl bg-[#0F4C5C] flex items-center justify-center text-xl">🧹</div>
                <div>
                  <h1 className="font-bold text-[#0F4C5C] text-xl">CleanPro Services</h1>
                  <p className="text-xs text-gray-500">Klang, Selangor, Malaysia</p>
                </div>
              </div>
              <p className="text-xs text-gray-500">+60 12-345 6789</p>
            </div>
            <div className="text-right">
              <h2 className="text-3xl font-bold text-[#0F4C5C]">INVOICE</h2>
              <p className="text-lg font-semibold text-gray-700 mt-1">{invoice.number}</p>
              <div className="mt-2 space-y-0.5 text-xs text-gray-500">
                <p>Issue: {format(new Date(invoice.issueDate || invoice.createdAt), 'dd MMM yyyy')}</p>
                <p>Due: {format(new Date(invoice.dueDate), 'dd MMM yyyy')}</p>
              </div>
              <span className={`inline-block mt-2 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                invoice.status === 'paid' ? 'bg-green-100 text-green-800' :
                invoice.status === 'overdue' ? 'bg-red-100 text-red-800' :
                'bg-yellow-100 text-yellow-800'
              }`}>
                {invoice.status.toUpperCase()}
              </span>
            </div>
          </div>

          {/* Bill to */}
          <div className="mb-6 p-4 bg-gray-50 rounded-xl">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Bill To</p>
            <p className="font-bold text-gray-800">{invoice.client?.name}</p>
            {invoice.client?.address && <p className="text-sm text-gray-600">{invoice.client.address}</p>}
            {invoice.client?.phone && <p className="text-sm text-gray-600">{invoice.client.phone}</p>}
          </div>

          {/* Items table */}
          <table className="w-full mb-6">
            <thead>
              <tr className="bg-[#0F4C5C] text-white">
                <th className="px-4 py-2.5 text-left text-sm font-semibold rounded-tl-lg">Description</th>
                <th className="px-4 py-2.5 text-center text-sm font-semibold">Qty</th>
                <th className="px-4 py-2.5 text-right text-sm font-semibold">Unit Price</th>
                <th className="px-4 py-2.5 text-right text-sm font-semibold rounded-tr-lg">Total</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.items ?? [{ description: 'Cleaning service', quantity: 1, unitPrice: invoice.total, total: invoice.total }]).map((item: any, i: number) => (
                <tr key={i} className={i % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}>
                  <td className="px-4 py-3 text-sm">{item.description}</td>
                  <td className="px-4 py-3 text-sm text-center">{item.quantity}</td>
                  <td className="px-4 py-3 text-sm text-right">RM {item.unitPrice?.toFixed(2)}</td>
                  <td className="px-4 py-3 text-sm text-right font-medium">RM {item.total?.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-56 space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Subtotal</span>
                <span>RM {invoice.subtotal?.toFixed(2)}</span>
              </div>
              {invoice.tax > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Tax</span>
                  <span>RM {invoice.tax?.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-base border-t border-gray-200 pt-2">
                <span>Total</span>
                <span className="text-[#0F4C5C]">RM {invoice.total?.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Notes */}
          {invoice.notes && (
            <div className="mt-6 p-4 bg-amber-50 rounded-xl border border-amber-100">
              <p className="text-xs font-semibold text-amber-700 mb-1">Notes</p>
              <p className="text-sm text-gray-700">{invoice.notes}</p>
            </div>
          )}

          {/* Footer */}
          <div className="mt-8 pt-4 border-t border-gray-100 text-center text-xs text-gray-400">
            <p>Thank you for your business! · CleanPro Services · +60 12-345 6789</p>
          </div>
        </div>
      </div>
    </div>
  )
}
