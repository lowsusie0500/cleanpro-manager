'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

const MOBILE_NAV = [
  { href: '/dashboard',    icon: '📊', key: 'dashboard' },
  { href: '/schedule',     icon: '📅', key: 'schedule' },
  { href: '/clients',      icon: '👥', key: 'clients' },
  { href: '/invoices',     icon: '🧾', key: 'invoices' },
  { href: '/daily-report', icon: '📝', key: 'report' },
]

export function MobileNav() {
  const pathname = usePathname()
  const { lang } = useLanguageStore()

  return (
    <nav className="mobile-nav lg:hidden">
      <div className="flex">
        {MOBILE_NAV.map(item => {
          const active = pathname === item.href
          return (
            <Link key={item.href} href={item.href}
              className={`flex-1 flex flex-col items-center py-2.5 gap-0.5 text-[10px] font-medium transition-colors ${active ? 'text-[#0F4C5C]' : 'text-gray-400'}`}>
              <span className="text-[20px] leading-none">{item.icon}</span>
              <span>{t(item.key, lang)}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
