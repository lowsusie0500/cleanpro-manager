'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { signOut } from 'next-auth/react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

const ALL_NAV = [
  { href: '/dashboard',    icon: '📊', key: 'dashboard' },
  { href: '/schedule',     icon: '📅', key: 'schedule' },
  { href: '/daily-report', icon: '📝', key: 'dailyReport' },
  { href: '/clients',      icon: '👥', key: 'clients' },
  { href: '/employees',    icon: '🚗', key: 'employees' },
  { href: '/quotes',       icon: '📋', key: 'quotes' },
  { href: '/invoices',     icon: '🧾', key: 'invoices' },
  { href: '/payments',     icon: '💳', key: 'payments' },
  { href: '/expenses',     icon: '💰', key: 'expenses' },
  { href: '/settings',     icon: '⚙️', key: 'settings' },
]

export function MobileHeader() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const { lang, setLang } = useLanguageStore()

  return (
    <>
      <header className="lg:hidden sticky top-0 z-40 bg-white border-b border-gray-200 flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center text-base" style={{ background: '#0F4C5C' }}>
            🧹
          </div>
          <span className="font-bold text-[#0F4C5C]">CleanPro</span>
        </div>
        <button onClick={() => setOpen(true)} className="text-gray-600 text-2xl leading-none">☰</button>
      </header>

      {/* Drawer overlay */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-[260px] flex flex-col" style={{ background: '#0F4C5C' }}>
            <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center text-lg" style={{ background: '#F0A500' }}>🧹</div>
                <span className="text-white font-bold">CleanPro</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-white/60 hover:text-white text-xl">✕</button>
            </div>

            <nav className="flex-1 overflow-y-auto py-3 px-3">
              {ALL_NAV.map(item => {
                const active = pathname === item.href
                return (
                  <Link key={item.href} href={item.href}
                    onClick={() => setOpen(false)}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg mb-0.5 text-sm font-medium transition-all ${active ? 'text-white' : 'text-white/65 hover:text-white hover:bg-white/10'}`}
                    style={active ? { background: 'rgba(255,255,255,0.15)' } : {}}>
                    <span className="text-base w-5 text-center">{item.icon}</span>
                    {t(item.key, lang)}
                  </Link>
                )
              })}
            </nav>

            <div className="px-3 py-3 border-t border-white/10 space-y-2">
              <button onClick={() => setLang(lang === 'en' ? 'zh' : 'en')}
                className="w-full text-left px-3 py-2 rounded-lg text-sm text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                {lang === 'en' ? '🇨🇳 切换中文' : '🇬🇧 Switch English'}
              </button>
              <button onClick={() => signOut({ callbackUrl: '/login' })}
                className="w-full text-left px-3 py-2 rounded-lg text-sm text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                ⏻ Sign Out
              </button>
            </div>
          </aside>
        </div>
      )}
    </>
  )
}
