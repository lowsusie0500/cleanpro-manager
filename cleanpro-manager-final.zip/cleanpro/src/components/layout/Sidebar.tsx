'use client'

import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { signOut } from 'next-auth/react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

const NAV_ITEMS = [
  { href: '/dashboard',    icon: '📊', key: 'dashboard',    section: 'main' },
  { href: '/schedule',     icon: '📅', key: 'schedule',     section: 'main' },
  { href: '/daily-report', icon: '📝', key: 'dailyReport',  section: 'main', badge: true },
  { href: '/clients',      icon: '👥', key: 'clients',      section: 'business' },
  { href: '/employees',    icon: '🚗', key: 'employees',    section: 'business' },
  { href: '/quotes',       icon: '📋', key: 'quotes',       section: 'business' },
  { href: '/invoices',     icon: '🧾', key: 'invoices',     section: 'business' },
  { href: '/payments',     icon: '💳', key: 'payments',     section: 'finance' },
  { href: '/expenses',     icon: '💰', key: 'expenses',     section: 'finance' },
  { href: '/settings',     icon: '⚙️', key: 'settings',     section: 'config' },
]

const SECTIONS = [
  { key: 'main',     label: { en: 'MAIN',    zh: '主要' } },
  { key: 'business', label: { en: 'BUSINESS', zh: '业务' } },
  { key: 'finance',  label: { en: 'FINANCE',  zh: '财务' } },
  { key: 'config',   label: { en: 'CONFIG',   zh: '配置' } },
]

export function Sidebar({ user }: { user: any }) {
  const pathname = usePathname()
  const { lang, setLang } = useLanguageStore()

  return (
    <aside className="hidden lg:flex fixed left-0 top-0 bottom-0 w-[240px] flex-col z-50"
      style={{ background: '#0F4C5C' }}>

      {/* Logo */}
      <div className="px-5 pt-6 pb-4 border-b border-white/10">
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xl"
            style={{ background: '#F0A500' }}>
            🧹
          </div>
          <div>
            <h2 className="text-white font-bold text-[15px]">CleanPro</h2>
            <p className="text-white/50 text-[11px]">
              {lang === 'zh' ? '保洁管理系统' : 'Management System'}
            </p>
          </div>
        </div>
        <button onClick={() => setLang(lang === 'en' ? 'zh' : 'en')}
          className="text-xs px-2.5 py-1 rounded-md text-white/70 hover:text-white transition-colors"
          style={{ background: 'rgba(255,255,255,0.1)' }}>
          {lang === 'en' ? '🇨🇳 中文' : '🇬🇧 English'}
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-2 px-3">
        {SECTIONS.map(section => {
          const items = NAV_ITEMS.filter(i => i.section === section.key)
          return (
            <div key={section.key} className="mb-2">
              <p className="text-[10px] font-semibold uppercase tracking-widest px-2 py-1.5"
                style={{ color: 'rgba(255,255,255,0.35)' }}>
                {section.label[lang]}
              </p>
              {items.map(item => {
                const active = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href))
                return (
                  <Link key={item.href} href={item.href}
                    className={`flex items-center gap-2.5 px-3 py-2 rounded-lg mb-0.5 text-[13.5px] font-medium transition-all ${active ? 'text-white' : 'text-white/65 hover:text-white hover:bg-white/10'}`}
                    style={active ? { background: 'rgba(255,255,255,0.15)' } : {}}>
                    <span className="text-base w-5 text-center">{item.icon}</span>
                    <span>{t(item.key, lang)}</span>
                    {item.badge && (
                      <span className="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full"
                        style={{ background: '#F0A500', color: '#333' }}>3</span>
                    )}
                  </Link>
                )
              })}
            </div>
          )
        })}
      </nav>

      {/* User footer */}
      <div className="px-3 py-3 border-t border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0"
            style={{ background: '#F0A500', color: '#333' }}>
            {user?.name?.[0] ?? 'A'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-xs font-semibold truncate">{user?.name}</p>
            <p className="text-white/40 text-[10px] truncate">{user?.email}</p>
          </div>
          <button onClick={() => signOut({ callbackUrl: '/login' })}
            className="text-white/40 hover:text-white text-sm transition-colors" title="Sign out">
            ⏻
          </button>
        </div>
      </div>
    </aside>
  )
}
