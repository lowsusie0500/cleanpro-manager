'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { COLOR_OPTIONS } from '@/lib/constants'

interface Props {
  onClose: () => void
  onSaved: (staff: any) => void
}

export function AddStaffModal({ onClose, onSaved }: Props) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name: '', phone: '', role: 'cleaner', area: '', icNumber: '', colorCode: 'teal',
  })

  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm({ ...form, [k]: e.target.value })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      onSaved(await res.json())
    } catch (err) { console.error(err) }
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold">🚗 {t('addStaff', lang)}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('name', lang)} *</label>
              <input required value={form.name} onChange={f('name')} placeholder="Kokoy"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('role', lang)}</label>
              <select value={form.role} onChange={f('role')}
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                <option value="cleaner">Cleaner</option>
                <option value="driver">Driver</option>
                <option value="supervisor">Supervisor</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Phone *</label>
              <input required value={form.phone} onChange={f('phone')} placeholder="+60 12-xxx xxxx"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('area', lang)} *</label>
              <input required value={form.area} onChange={f('area')} placeholder="Klang, PJ..."
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">IC / ID Number</label>
            <input value={form.icNumber} onChange={f('icNumber')} placeholder="880101-01-1234"
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{lang === 'zh' ? '颜色标识' : 'Color Tag'}</label>
            <div className="flex gap-2 flex-wrap">
              {COLOR_OPTIONS.map(c => (
                <button key={c.value} type="button"
                  onClick={() => setForm({ ...form, colorCode: c.value })}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border-2 transition-all ${form.colorCode === c.value ? 'border-gray-800 scale-105' : 'border-transparent'}`}
                  style={{ background: { teal: '#E6F4F7', amber: '#FFF8E6', green: '#F0FFF4', purple: '#FAF5FF', pink: '#FFF5F7', blue: '#EBF8FF' }[c.value], color: { teal: '#0F4C5C', amber: '#744210', green: '#276749', purple: '#553C9A', pink: '#97266D', blue: '#2A4365' }[c.value] }}>
                  {c.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">
              {t('cancel', lang)}
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? '...' : t('save', lang)}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
