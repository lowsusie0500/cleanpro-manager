'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { FREQUENCY_OPTIONS } from '@/lib/constants'

interface Props {
  client: any
  staff: any[]
  onClose: () => void
  onSaved: (updated: any) => void
}

export function EditClientModal({ client, staff, onClose, onSaved }: Props) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name:            client.name            ?? '',
    phone:           client.phone           ?? '',
    email:           client.email           ?? '',
    address:         client.address         ?? '',
    area:            client.area            ?? '',
    frequency:       client.frequency       ?? 'weekly',
    assignedStaffId: client.assignedStaffId ?? '',
    notes:           client.notes           ?? '',
    status:          client.status          ?? 'active',
  })

  const set = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
      setForm({ ...form, [k]: e.target.value })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch(`/api/clients/${client.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error('Failed')
      onSaved(await res.json())
    } catch (err) {
      console.error(err)
      alert('Failed to save. Please try again.')
    }
    setLoading(false)
  }

  const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] transition-colors'

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold">✏️ {lang === 'zh' ? '编辑客户' : 'Edit Client'}</h2>
            <p className="text-xs text-gray-400 mt-0.5">{client.name}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('name', lang)} *</label>
              <input required value={form.name} onChange={set('name')} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Phone *</label>
              <input required value={form.phone} onChange={set('phone')} className={inputCls} />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Email</label>
            <input type="email" value={form.email} onChange={set('email')} className={inputCls} />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Address *</label>
            <input required value={form.address} onChange={set('address')} className={inputCls} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('area', lang)} *</label>
              <input required value={form.area} onChange={set('area')} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('frequency', lang)}</label>
              <select value={form.frequency} onChange={set('frequency')} className={inputCls}>
                {FREQUENCY_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">
                {lang === 'zh' ? '分配员工' : 'Assigned Staff'}
              </label>
              <select value={form.assignedStaffId} onChange={set('assignedStaffId')} className={inputCls}>
                <option value="">— None —</option>
                {staff.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('status', lang)}</label>
              <select value={form.status} onChange={set('status')} className={inputCls}>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="suspended">Suspended</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('notes', lang)}</label>
            <textarea rows={2} value={form.notes} onChange={set('notes')}
              placeholder="Special requirements..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none transition-colors" />
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">
              {t('cancel', lang)}
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? (lang === 'zh' ? '保存中...' : 'Saving...') : (lang === 'zh' ? '保存更改' : 'Save Changes')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
