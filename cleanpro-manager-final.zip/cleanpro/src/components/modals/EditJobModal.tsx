'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { FREQUENCY_OPTIONS } from '@/lib/constants'

interface Props {
  job: any
  staff: any[]
  clients: any[]
  onClose: () => void
  onSaved: (updated: any) => void
}

export function EditJobModal({ job, staff, clients, onClose, onSaved }: Props) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    clientId:  job.clientId  ?? job.client?.id  ?? '',
    staffId:   job.staffId   ?? job.staff?.id   ?? '',
    date:      new Date(job.date).toISOString().split('T')[0],
    startTime: job.startTime ?? '08:00',
    endTime:   job.endTime   ?? '12:00',
    frequency: job.frequency ?? 'once',
    status:    job.status    ?? 'scheduled',
    notes:     job.notes     ?? '',
  })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch(`/api/jobs/${job.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error('Failed')
      const updated = await res.json()
      onSaved(updated)
    } catch (err) {
      console.error(err)
      alert('Failed to save. Please try again.')
    }
    setLoading(false)
  }

  const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] transition-colors'

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold">✏️ {lang === 'zh' ? '编辑工作' : 'Edit Job'}</h2>
            <p className="text-xs text-gray-400 mt-0.5">{job.client?.name ?? 'Job'}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Client */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Client</label>
            <select value={form.clientId} onChange={e => setForm({ ...form, clientId: e.target.value })} className={inputCls}>
              {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          {/* Staff */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">
              {lang === 'zh' ? '分配员工' : 'Assigned Staff'}
            </label>
            <select value={form.staffId} onChange={e => setForm({ ...form, staffId: e.target.value })} className={inputCls}>
              {staff.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>

          {/* Date + Frequency */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('date', lang)}</label>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">
                {lang === 'zh' ? '频率' : 'Frequency'}
              </label>
              <select value={form.frequency} onChange={e => setForm({ ...form, frequency: e.target.value })} className={inputCls}>
                {FREQUENCY_OPTIONS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
              </select>
            </div>
          </div>

          {/* Start + End time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">
                {lang === 'zh' ? '开始时间' : 'Start Time'}
              </label>
              <input type="time" value={form.startTime} onChange={e => setForm({ ...form, startTime: e.target.value })} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">
                {lang === 'zh' ? '结束时间' : 'End Time'}
              </label>
              <input type="time" value={form.endTime} onChange={e => setForm({ ...form, endTime: e.target.value })} className={inputCls} />
            </div>
          </div>

          {/* Status */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">
              {t('status', lang)}
            </label>
            <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className={inputCls}>
              <option value="scheduled">Scheduled</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
              <option value="rescheduled">Rescheduled</option>
            </select>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('notes', lang)}</label>
            <textarea
              rows={2}
              value={form.notes}
              onChange={e => setForm({ ...form, notes: e.target.value })}
              placeholder={lang === 'zh' ? '特别说明...' : 'Special instructions...'}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none transition-colors"
            />
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">
              {t('cancel', lang)}
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? (lang === 'zh' ? '保存中...' : 'Saving...') : (lang === 'zh' ? '保存更改' : 'Save Changes')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
