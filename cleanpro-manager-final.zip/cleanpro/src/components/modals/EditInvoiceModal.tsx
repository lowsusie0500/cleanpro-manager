'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

interface LineItem {
  id?: string
  description: string
  quantity: number
  unitPrice: number
  total: number
}

interface Props {
  invoice: any
  clients: any[]
  onClose: () => void
  onSaved: (updated: any) => void
}

export function EditInvoiceModal({ invoice, clients, onClose, onSaved }: Props) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)

  const [clientId, setClientId] = useState(invoice.clientId ?? invoice.client?.id ?? '')
  const [dueDate, setDueDate] = useState(
    new Date(invoice.dueDate).toISOString().split('T')[0]
  )
  const [status, setStatus] = useState(invoice.status ?? 'pending')
  const [notes, setNotes] = useState(invoice.notes ?? '')
  const [tax, setTax] = useState<number>(
    invoice.subtotal > 0 ? Math.round(((invoice.tax ?? 0) / invoice.subtotal) * 100) : 0
  )
  const [items, setItems] = useState<LineItem[]>(
    invoice.items?.length
      ? invoice.items.map((it: any) => ({
          id: it.id,
          description: it.description ?? '',
          quantity: it.quantity ?? 1,
          unitPrice: it.unitPrice ?? 0,
          total: it.total ?? 0,
        }))
      : [{ description: 'Cleaning service', quantity: 1, unitPrice: invoice.total ?? 0, total: invoice.total ?? 0 }]
  )

  function updateItem(i: number, field: keyof LineItem, val: string | number) {
    setItems(prev => {
      const next = [...prev]
      next[i] = { ...next[i], [field]: val }
      if (field === 'quantity' || field === 'unitPrice') {
        next[i].total = Number(next[i].quantity) * Number(next[i].unitPrice)
      }
      return next
    })
  }

  function addItem() {
    setItems(prev => [...prev, { description: '', quantity: 1, unitPrice: 0, total: 0 }])
  }

  function removeItem(i: number) {
    if (items.length === 1) return // keep at least one
    setItems(prev => prev.filter((_, j) => j !== i))
  }

  const subtotal = items.reduce((s, it) => s + Number(it.total), 0)
  const taxAmt   = subtotal * (tax / 100)
  const total    = subtotal + taxAmt

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch(`/api/invoices/${invoice.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId,
          dueDate,
          status,
          notes,
          subtotal,
          tax: taxAmt,
          total,
          items: items.map(it => ({
            id: it.id,
            description: it.description,
            quantity: Number(it.quantity),
            unitPrice: Number(it.unitPrice),
            total: Number(it.total),
          })),
        }),
      })
      if (!res.ok) throw new Error('Failed')
      const updated = await res.json()
      onSaved(updated)
    } catch (err) {
      console.error(err)
      alert('Failed to save. Please try again.')
    }
    setLoading(false)
  }

  const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] transition-colors'

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl p-6 max-h-[92vh] overflow-y-auto">

        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold">✏️ {lang === 'zh' ? '编辑发票' : 'Edit Invoice'}</h2>
            <p className="text-xs text-gray-400 mt-0.5">{invoice.number}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">

          {/* Client + Due date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Client</label>
              <select value={clientId} onChange={e => setClientId(e.target.value)} className={inputCls}>
                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Due Date</label>
              <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} className={inputCls} />
            </div>
          </div>

          {/* Status */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('status', lang)}</label>
            <select value={status} onChange={e => setStatus(e.target.value)} className={inputCls}>
              <option value="pending">Pending</option>
              <option value="paid">Paid</option>
              <option value="overdue">Overdue</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>

          {/* Line items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-gray-600">Line Items</label>
              <button type="button" onClick={addItem}
                className="text-xs text-[#0F4C5C] hover:underline font-medium">
                + Add line
              </button>
            </div>

            {/* Column headers */}
            <div className="grid grid-cols-[1fr_52px_80px_72px_24px] gap-1.5 mb-1 px-0.5">
              {['Description', 'Qty', 'Unit (RM)', 'Total', ''].map(h => (
                <div key={h} className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{h}</div>
              ))}
            </div>

            <div className="space-y-1.5">
              {items.map((item, i) => (
                <div key={i} className="grid grid-cols-[1fr_52px_80px_72px_24px] gap-1.5 items-center">
                  <input
                    value={item.description}
                    onChange={e => updateItem(i, 'description', e.target.value)}
                    placeholder="Description"
                    className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] transition-colors"
                  />
                  <input
                    type="number" min="0.01" step="0.01"
                    value={item.quantity}
                    onChange={e => updateItem(i, 'quantity', parseFloat(e.target.value) || 1)}
                    className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] text-center transition-colors"
                  />
                  <input
                    type="number" min="0" step="0.01"
                    value={item.unitPrice}
                    onChange={e => updateItem(i, 'unitPrice', parseFloat(e.target.value) || 0)}
                    className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] transition-colors"
                  />
                  <div className="px-2 py-1.5 text-xs font-semibold text-right text-gray-700">
                    {Number(item.total).toFixed(2)}
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(i)}
                    disabled={items.length === 1}
                    className="text-gray-300 hover:text-red-500 transition-colors disabled:opacity-20 leading-none text-base"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="border-t border-gray-100 pt-3 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Subtotal</span>
              <span className="font-medium">RM {subtotal.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Tax (%)</span>
              <div className="flex items-center gap-2">
                <input
                  type="number" min="0" max="100" step="0.5"
                  value={tax}
                  onChange={e => setTax(parseFloat(e.target.value) || 0)}
                  className="w-16 px-2 py-1 text-xs border border-gray-200 rounded text-center focus:outline-none focus:border-[#0F4C5C]"
                />
                <span className="font-medium text-gray-700 w-20 text-right">RM {taxAmt.toFixed(2)}</span>
              </div>
            </div>
            <div className="flex justify-between font-bold text-base pt-1 border-t border-gray-100">
              <span>Total</span>
              <span className="text-[#0F4C5C]">RM {total.toFixed(2)}</span>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('notes', lang)}</label>
            <textarea
              rows={2}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Payment terms, bank details..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none transition-colors"
            />
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">
              {t('cancel', lang)}
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? (lang === 'zh' ? '保存中...' : 'Saving...') : (lang === 'zh' ? '保存更改' : 'Save Changes')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
