'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

interface LineItem { description: string; quantity: number; unitPrice: number; total: number }

interface Props {
  clients: any[]
  onClose: () => void
  onSaved: (invoice: any) => void
}

export function AddInvoiceModal({ clients, onClose, onSaved }: Props) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [clientId, setClientId] = useState(clients[0]?.id ?? '')
  const [dueDate, setDueDate] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() + 14)
    return d.toISOString().split('T')[0]
  })
  const [tax, setTax] = useState(0)
  const [notes, setNotes] = useState('')
  const [items, setItems] = useState<LineItem[]>([
    { description: 'Regular cleaning service', quantity: 1, unitPrice: 350, total: 350 },
  ])

  function updateItem(i: number, field: keyof LineItem, val: string | number) {
    setItems(prev => {
      const next = [...prev]
      next[i] = { ...next[i], [field]: val }
      if (field === 'quantity' || field === 'unitPrice') {
        next[i].total = Number(next[i].quantity) * Number(next[i].unitPrice)
      }
      return next
    })
  }

  function addItem() {
    setItems(prev => [...prev, { description: '', quantity: 1, unitPrice: 0, total: 0 }])
  }

  function removeItem(i: number) {
    setItems(prev => prev.filter((_, j) => j !== i))
  }

  const subtotal = items.reduce((s, it) => s + it.total, 0)
  const taxAmt = subtotal * (tax / 100)
  const total = subtotal + taxAmt

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clientId, dueDate, items, subtotal, tax: taxAmt, total, notes }),
      })
      onSaved(await res.json())
    } catch (err) { console.error(err) }
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl p-6 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold">🧾 {lang === 'zh' ? '新建发票' : 'New Invoice'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Client *</label>
              <select value={clientId} onChange={e => setClientId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Due Date *</label>
              <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
          </div>

          {/* Line items */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-2">Line Items</label>
            <div className="space-y-2">
              {items.map((item, i) => (
                <div key={i} className="grid grid-cols-[1fr_60px_80px_80px_28px] gap-1.5 items-center">
                  <input value={item.description} onChange={e => updateItem(i, 'description', e.target.value)}
                    placeholder="Description" className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
                  <input type="number" value={item.quantity} onChange={e => updateItem(i, 'quantity', parseFloat(e.target.value) || 1)}
                    className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] text-center" />
                  <input type="number" value={item.unitPrice} onChange={e => updateItem(i, 'unitPrice', parseFloat(e.target.value) || 0)}
                    className="px-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
                  <div className="px-2 py-1.5 text-xs font-semibold text-right">RM {item.total.toFixed(2)}</div>
                  <button type="button" onClick={() => removeItem(i)}
                    className="text-red-400 hover:text-red-600 text-sm leading-none">✕</button>
                </div>
              ))}
            </div>
            <button type="button" onClick={addItem}
              className="mt-2 text-xs text-[#0F4C5C] hover:underline">+ Add line item</button>
          </div>

          {/* Totals */}
          <div className="border-t border-gray-100 pt-3 space-y-1.5">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Subtotal</span>
              <span className="font-medium">RM {subtotal.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Tax (%)</span>
              <div className="flex items-center gap-2">
                <input type="number" value={tax} onChange={e => setTax(parseFloat(e.target.value) || 0)}
                  className="w-16 px-2 py-1 text-xs border border-gray-200 rounded focus:outline-none focus:border-[#0F4C5C] text-center" />
                <span className="font-medium">RM {taxAmt.toFixed(2)}</span>
              </div>
            </div>
            <div className="flex justify-between text-base font-bold border-t border-gray-100 pt-2">
              <span>Total</span>
              <span className="text-[#0F4C5C]">RM {total.toFixed(2)}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('notes', lang)}</label>
            <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)}
              placeholder="Payment terms, bank details..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none" />
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">
              {t('cancel', lang)}
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? '...' : lang === 'zh' ? '创建发票' : 'Create Invoice'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
