'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { COLOR_OPTIONS, STAFF_COLORS } from '@/lib/constants'

interface Props {
  employee: any
  onClose: () => void
  onSaved: (updated: any) => void
}

export function EditStaffModal({ employee, onClose, onSaved }: Props) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name:      employee.name      ?? '',
    phone:     employee.phone     ?? '',
    role:      employee.role      ?? 'cleaner',
    area:      employee.area      ?? '',
    icNumber:  employee.icNumber  ?? '',
    colorCode: employee.colorCode ?? 'teal',
    status:    employee.status    ?? 'active',
  })

  const set = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm({ ...form, [k]: e.target.value })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch(`/api/staff/${employee.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) throw new Error('Failed')
      onSaved(await res.json())
    } catch (err) {
      console.error(err)
      alert('Failed to save. Please try again.')
    }
    setLoading(false)
  }

  const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] transition-colors'

  const colorBg: Record<string, string> = {
    teal: '#E6F4F7', amber: '#FFF8E6', green: '#F0FFF4',
    purple: '#FAF5FF', pink: '#FFF5F7', blue: '#EBF8FF',
  }
  const colorFg: Record<string, string> = {
    teal: '#0F4C5C', amber: '#744210', green: '#276749',
    purple: '#553C9A', pink: '#97266D', blue: '#2A4365',
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-lg font-bold">✏️ {lang === 'zh' ? '编辑员工' : 'Edit Staff'}</h2>
            <p className="text-xs text-gray-400 mt-0.5">{employee.name}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('name', lang)} *</label>
              <input required value={form.name} onChange={set('name')} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('role', lang)}</label>
              <select value={form.role} onChange={set('role')} className={inputCls}>
                <option value="cleaner">Cleaner</option>
                <option value="driver">Driver</option>
                <option value="supervisor">Supervisor</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Phone *</label>
              <input required value={form.phone} onChange={set('phone')} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('area', lang)} *</label>
              <input required value={form.area} onChange={set('area')} className={inputCls} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">IC / ID Number</label>
              <input value={form.icNumber} onChange={set('icNumber')} placeholder="880101-01-1234" className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('status', lang)}</label>
              <select value={form.status} onChange={set('status')} className={inputCls}>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="leave">On Leave</option>
              </select>
            </div>
          </div>

          {/* Color tag picker */}
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-2">
              {lang === 'zh' ? '颜色标识' : 'Schedule Color'}
            </label>
            <div className="flex gap-2 flex-wrap">
              {COLOR_OPTIONS.map(c => (
                <button
                  key={c.value}
                  type="button"
                  onClick={() => setForm({ ...form, colorCode: c.value })}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border-2 transition-all ${
                    form.colorCode === c.value ? 'border-gray-700 scale-105 shadow-sm' : 'border-transparent opacity-80 hover:opacity-100'
                  }`}
                  style={{ background: colorBg[c.value], color: colorFg[c.value] }}
                >
                  {c.label}
                </button>
              ))}
            </div>
            {/* Preview */}
            <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: STAFF_COLORS[form.colorCode as keyof typeof STAFF_COLORS] ?? '#999' }}
              />
              Schedule blocks will use this colour
            </div>
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">
              {t('cancel', lang)}
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? (lang === 'zh' ? '保存中...' : 'Saving...') : (lang === 'zh' ? '保存更改' : 'Save Changes')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
