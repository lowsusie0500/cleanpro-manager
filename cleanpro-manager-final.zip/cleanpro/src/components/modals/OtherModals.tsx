'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { SERVICE_TYPES, PAYMENT_METHODS, EXPENSE_CATEGORIES } from '@/lib/constants'

// ── Add Quote Modal ────────────────────────────────────────────────
export function AddQuoteModal({ onClose, onSaved }: { onClose: () => void; onSaved: (q: any) => void }) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    clientName: '', clientPhone: '', serviceType: SERVICE_TYPES[0],
    propertySize: '', amount: '', notes: '',
  })
  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm({ ...form, [k]: e.target.value })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true)
    try {
      const res = await fetch('/api/quotes', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, propertySize: parseFloat(form.propertySize) || undefined, amount: parseFloat(form.amount) || 0 }),
      })
      onSaved(await res.json())
    } catch (err) { console.error(err) }
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold">📋 {lang === 'zh' ? '新建报价单' : 'New Quote'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Client Name *</label>
              <input required value={form.clientName} onChange={f('clientName')} placeholder="Mrs. Tan"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Phone</label>
              <input value={form.clientPhone} onChange={f('clientPhone')} placeholder="+60 12-xxx xxxx"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Service Type</label>
            <select value={form.serviceType} onChange={f('serviceType')}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
              {SERVICE_TYPES.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Property Size (sqft)</label>
              <input type="number" value={form.propertySize} onChange={f('propertySize')} placeholder="1200"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Quoted Price (RM) *</label>
              <input required type="number" value={form.amount} onChange={f('amount')} placeholder="350"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('notes', lang)}</label>
            <textarea rows={2} value={form.notes} onChange={f('notes')} placeholder="Special requirements..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none" />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">{t('cancel', lang)}</button>
            <button type="submit" disabled={loading} className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? '...' : lang === 'zh' ? '发送报价' : 'Send Quote'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ── Add Payment Modal ──────────────────────────────────────────────
export function AddPaymentModal({ clients, invoices, onClose, onSaved }: { clients: any[]; invoices: any[]; onClose: () => void; onSaved: (p: any) => void }) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    clientId: clients[0]?.id ?? '', invoiceId: '', amount: '', method: 'cash',
    reference: '', date: new Date().toISOString().split('T')[0], notes: '',
  })
  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setForm({ ...form, [k]: e.target.value })

  const clientInvoices = invoices.filter(i => i.clientId === form.clientId)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true)
    try {
      const res = await fetch('/api/payments', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, amount: parseFloat(form.amount) || 0, invoiceId: form.invoiceId || undefined }),
      })
      onSaved(await res.json())
    } catch (err) { console.error(err) }
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold">💳 {lang === 'zh' ? '记录付款' : 'Record Payment'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Client *</label>
              <select value={form.clientId} onChange={f('clientId')} className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Invoice</label>
              <select value={form.invoiceId} onChange={f('invoiceId')} className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                <option value="">— None —</option>
                {clientInvoices.map(i => <option key={i.id} value={i.id}>{i.number} (RM{i.total})</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Amount (RM) *</label>
              <input required type="number" step="0.01" value={form.amount} onChange={f('amount')} placeholder="0.00"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Method</label>
              <select value={form.method} onChange={f('method')} className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                {PAYMENT_METHODS.map(m => <option key={m.value} value={m.value}>{m.icon} {m.label}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('date', lang)}</label>
              <input type="date" value={form.date} onChange={f('date')} className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Reference No.</label>
              <input value={form.reference} onChange={f('reference')} placeholder="Optional"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">{t('cancel', lang)}</button>
            <button type="submit" disabled={loading} className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? '...' : lang === 'zh' ? '保存' : 'Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ── Add Expense Modal ──────────────────────────────────────────────
export function AddExpenseModal({ staff, onClose, onSaved }: { staff: any[]; onClose: () => void; onSaved: (e: any) => void }) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    staffId: staff[0]?.id ?? '', category: 'fuel', description: '', amount: '',
    date: new Date().toISOString().split('T')[0],
  })
  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setForm({ ...form, [k]: e.target.value })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true)
    try {
      const res = await fetch('/api/expenses', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, amount: parseFloat(form.amount) || 0 }),
      })
      onSaved(await res.json())
    } catch (err) { console.error(err) }
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold">💰 {lang === 'zh' ? '新增费用' : 'Add Expense'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('date', lang)}</label>
              <input type="date" value={form.date} onChange={f('date')} className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Category</label>
              <select value={form.category} onChange={f('category')} className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                {EXPENSE_CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.icon} {c.label}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Staff</label>
            <select value={form.staffId} onChange={f('staffId')} className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
              {staff.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Description *</label>
            <input required value={form.description} onChange={f('description')} placeholder="Petrol for van"
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Amount (RM) *</label>
            <input required type="number" step="0.01" value={form.amount} onChange={f('amount')} placeholder="0.00"
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose} className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">{t('cancel', lang)}</button>
            <button type="submit" disabled={loading} className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? '...' : t('save', lang)}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
