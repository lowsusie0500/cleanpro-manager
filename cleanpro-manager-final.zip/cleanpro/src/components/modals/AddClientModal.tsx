'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { FREQUENCY_OPTIONS } from '@/lib/constants'

interface Props {
  staff: any[]
  onClose: () => void
  onSaved: (client: any) => void
}

export function AddClientModal({ staff, onClose, onSaved }: Props) {
  const { lang } = useLanguageStore()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name: '', phone: '', email: '', address: '', area: '',
    frequency: 'weekly', assignedStaffId: staff[0]?.id ?? '', notes: '',
  })

  const f = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm({ ...form, [k]: e.target.value })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      onSaved(await res.json())
    } catch (err) { console.error(err) }
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold">👥 {t('addClient', lang)}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('name', lang)} *</label>
              <input required value={form.name} onChange={f('name')} placeholder="Mrs. Wong"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Phone *</label>
              <input required value={form.phone} onChange={f('phone')} placeholder="+60 12-xxx xxxx"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Email</label>
            <input type="email" value={form.email} onChange={f('email')} placeholder="optional"
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Address *</label>
            <input required value={form.address} onChange={f('address')} placeholder="No. 12, Jalan..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('area', lang)} *</label>
              <input required value={form.area} onChange={f('area')} placeholder="Telok Gadong"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('frequency', lang)}</label>
              <select value={form.frequency} onChange={f('frequency')}
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                {FREQUENCY_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{lang === 'zh' ? '分配员工' : 'Assign Staff'}</label>
            <select value={form.assignedStaffId} onChange={f('assignedStaffId')}
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
              {staff.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('notes', lang)}</label>
            <textarea rows={2} value={form.notes} onChange={f('notes')} placeholder="Special requirements..."
              className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none" />
          </div>
          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 border border-gray-200 rounded-lg text-sm font-medium hover:border-gray-400 transition-colors">
              {t('cancel', lang)}
            </button>
            <button type="submit" disabled={loading}
              className="flex-1 py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg text-sm font-semibold transition-colors disabled:opacity-60">
              {loading ? '...' : t('save', lang)}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
