'use client'

import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

export default function LoginPage() {
  const [email, setEmail] = useState('admin@cleanpro.com')
  const [password, setPassword] = useState('admin123')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { lang, setLang } = useLanguageStore()

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const res = await signIn('credentials', {
      email, password, redirect: false,
    })
    setLoading(false)
    if (res?.error) setError(t('invalidCredentials', lang))
    else router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(135deg, #0F4C5C 0%, #1a6b80 50%, #0a3340 100%)' }}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-[420px] p-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-[#0F4C5C] flex items-center justify-center text-3xl mx-auto mb-3">
            🧹
          </div>
          <h1 className="text-2xl font-bold text-[#0F4C5C]">CleanPro</h1>
          <p className="text-sm text-gray-500 mt-1">
            {lang === 'zh' ? '专业保洁管理系统' : 'Professional Cleaning Management'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              {t('email', lang)}
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#0F4C5C] transition-colors"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">
              {t('password', lang)}
            </label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-[#0F4C5C] transition-colors"
              required
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white rounded-lg font-semibold text-sm transition-colors disabled:opacity-60"
          >
            {loading ? '...' : t('signIn', lang)}
          </button>
        </form>

        <div className="flex justify-center gap-3 mt-6">
          <button onClick={() => setLang('en')}
            className={`px-4 py-1.5 rounded-full text-xs font-medium border transition-all ${lang === 'en' ? 'bg-[#0F4C5C] text-white border-[#0F4C5C]' : 'border-gray-200 text-gray-600 hover:border-[#0F4C5C]'}`}>
            🇬🇧 EN
          </button>
          <button onClick={() => setLang('zh')}
            className={`px-4 py-1.5 rounded-full text-xs font-medium border transition-all ${lang === 'zh' ? 'bg-[#0F4C5C] text-white border-[#0F4C5C]' : 'border-gray-200 text-gray-600 hover:border-[#0F4C5C]'}`}>
            🇨🇳 中文
          </button>
        </div>

        <p className="text-center text-xs text-gray-400 mt-4">
          {lang === 'zh' ? '演示账号: admin@cleanpro.com / admin123' : 'Demo: admin@cleanpro.com / admin123'}
        </p>
      </div>
    </div>
  )
}
