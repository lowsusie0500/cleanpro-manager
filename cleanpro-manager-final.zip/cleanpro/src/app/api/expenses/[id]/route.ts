import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  const expense = await prisma.expense.findUnique({
    where: { id: params.id },
    include: { staff: true },
  })
  if (!expense) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(expense)
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { id: _id, createdAt: _ca, updatedAt: _ua, staff: _s, ...data } = body
  if (data.date) data.date = new Date(data.date)

  const expense = await prisma.expense.update({
    where: { id: params.id },
    data,
    include: { staff: true },
  })
  return NextResponse.json(expense)
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  await prisma.expense.delete({ where: { id: params.id } })
  return NextResponse.json({ success: true })
}
