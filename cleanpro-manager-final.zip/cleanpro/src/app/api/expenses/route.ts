import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET() {
  const expenses = await prisma.expense.findMany({
    include: { staff: true },
    orderBy: { date: 'desc' },
  })
  return NextResponse.json(expenses)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()
  const expense = await prisma.expense.create({
    data: {
      staffId: body.staffId || undefined,
      category: body.category,
      description: body.description,
      amount: body.amount,
      date: body.date ? new Date(body.date) : new Date(),
      receiptUrl: body.receiptUrl,
    },
    include: { staff: true },
  })
  return NextResponse.json(expense, { status: 201 })
}
