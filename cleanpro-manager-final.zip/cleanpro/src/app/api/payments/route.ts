import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET() {
  const payments = await prisma.payment.findMany({
    include: { client: true, invoice: true },
    orderBy: { date: 'desc' },
  })
  return NextResponse.json(payments)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()
  const payment = await prisma.payment.create({
    data: {
      clientId: body.clientId,
      invoiceId: body.invoiceId || undefined,
      amount: body.amount,
      method: body.method,
      reference: body.reference,
      date: body.date ? new Date(body.date) : new Date(),
      notes: body.notes,
    },
    include: { client: true, invoice: true },
  })
  // Mark invoice as paid if amount matches
  if (body.invoiceId) {
    const inv = await prisma.invoice.findUnique({ where: { id: body.invoiceId } })
    if (inv && payment.amount >= inv.total) {
      await prisma.invoice.update({ where: { id: body.invoiceId }, data: { status: 'paid' } })
    }
  }
  return NextResponse.json(payment, { status: 201 })
}
