import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET() {
  const reports = await prisma.dailyReport.findMany({
    include: { staff: true },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })
  return NextResponse.json(reports)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()
  const report = await prisma.dailyReport.create({
    data: {
      staffId: body.staffId,
      date: body.date ? new Date(body.date) : new Date(),
      clientName: body.clientName,
      cashReceived: body.cashReceived ?? 0,
      notes: body.notes,
      photos: body.photos,
      submitted: body.submitted ?? true,
    },
    include: { staff: true },
  })
  return NextResponse.json(report, { status: 201 })
}
