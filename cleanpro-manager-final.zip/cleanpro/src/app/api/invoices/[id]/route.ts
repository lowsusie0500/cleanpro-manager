import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  const invoice = await prisma.invoice.findUnique({
    where: { id: params.id },
    include: { client: true, items: true },
  })
  if (!invoice) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(invoice)
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { items, id: _id, createdAt: _ca, updatedAt: _ua, client: _c, ...invoiceData } = body

  // Update scalar fields
  if (invoiceData.dueDate) invoiceData.dueDate = new Date(invoiceData.dueDate)

  // If line items are included, sync them: delete old ones and recreate
  if (items && Array.isArray(items)) {
    // Delete all existing items for this invoice
    await prisma.invoiceItem.deleteMany({ where: { invoiceId: params.id } })

    // Recreate from the submitted list
    await prisma.invoiceItem.createMany({
      data: items.map((it: any) => ({
        invoiceId: params.id,
        description: it.description ?? '',
        quantity:   Number(it.quantity)  || 1,
        unitPrice:  Number(it.unitPrice) || 0,
        total:      Number(it.total)     || 0,
      })),
    })
  }

  const invoice = await prisma.invoice.update({
    where: { id: params.id },
    data: invoiceData,
    include: { client: true, items: true },
  })

  return NextResponse.json(invoice)
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  await prisma.invoice.update({
    where: { id: params.id },
    data: { status: 'cancelled' },
  })
  return NextResponse.json({ success: true })
}
