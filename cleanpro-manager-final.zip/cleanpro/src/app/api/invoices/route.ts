import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET() {
  const invoices = await prisma.invoice.findMany({
    include: { client: true, items: true },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json(invoices)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()

  // Auto-generate invoice number
  const count = await prisma.invoice.count()
  const number = `INV-${String(count + 1).padStart(3, '0')}`

  const invoice = await prisma.invoice.create({
    data: {
      number,
      clientId: body.clientId,
      dueDate: new Date(body.dueDate),
      subtotal: body.subtotal,
      tax: body.tax ?? 0,
      total: body.total,
      status: 'pending',
      notes: body.notes,
      items: {
        create: body.items?.map((item: any) => ({
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          total: item.total,
        })) ?? [],
      },
    },
    include: { client: true, items: true },
  })
  return NextResponse.json(invoice, { status: 201 })
}
