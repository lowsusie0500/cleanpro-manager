import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(req.url)
  const from = searchParams.get('from')
  const to = searchParams.get('to')
  const jobs = await prisma.job.findMany({
    where: {
      ...(from && to ? { date: { gte: new Date(from), lte: new Date(to) } } : {}),
    },
    include: { client: true, staff: true },
    orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
  })
  return NextResponse.json(jobs)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()
  const job = await prisma.job.create({
    data: {
      clientId: body.clientId,
      staffId: body.staffId,
      date: new Date(body.date),
      startTime: body.startTime,
      endTime: body.endTime,
      frequency: body.frequency ?? 'once',
      status: 'scheduled',
      notes: body.notes,
    },
    include: { client: true, staff: true },
  })
  return NextResponse.json(job, { status: 201 })
}
