import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()
  const data: any = { ...body }
  if (body.date) data.date = new Date(body.date)
  const job = await prisma.job.update({
    where: { id: params.id },
    data,
    include: { client: true, staff: true },
  })
  return NextResponse.json(job)
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  await prisma.job.delete({ where: { id: params.id } })
  return NextResponse.json({ success: true })
}
