import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  const staff = await prisma.staff.findUnique({ where: { id: params.id } })
  if (!staff) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(staff)
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  // Never allow id or createdAt to be overwritten
  const { id: _id, createdAt: _ca, updatedAt: _ua, ...data } = body

  const staff = await prisma.staff.update({
    where: { id: params.id },
    data,
  })
  return NextResponse.json(staff)
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  // Soft-delete: mark inactive rather than destroy relational data
  const staff = await prisma.staff.update({
    where: { id: params.id },
    data: { status: 'inactive' },
  })
  return NextResponse.json(staff)
}
