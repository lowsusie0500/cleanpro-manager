import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET() {
  const quotes = await prisma.quote.findMany({ orderBy: { createdAt: 'desc' } })
  return NextResponse.json(quotes)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json()
  const count = await prisma.quote.count()
  const number = `QT-${String(count + 1).padStart(3, '0')}`
  const quote = await prisma.quote.create({
    data: { ...body, number, validUntil: body.validUntil ? new Date(body.validUntil) : undefined },
  })
  return NextResponse.json(quote, { status: 201 })
}
