import { prisma } from '@/lib/prisma'
import { DailyReportClient } from './DailyReportClient'

export default async function DailyReportPage() {
  const [reports, staff, clients] = await Promise.all([
    prisma.dailyReport.findMany({
      include: { staff: true },
      orderBy: { createdAt: 'desc' },
      take: 50,
    }),
    prisma.staff.findMany({ where: { status: 'active' }, select: { id: true, name: true } }),
    prisma.client.findMany({ where: { status: 'active' }, select: { id: true, name: true } }),
  ])
  return (
    <DailyReportClient
      reports={JSON.parse(JSON.stringify(reports))}
      staff={JSON.parse(JSON.stringify(staff))}
      clients={JSON.parse(JSON.stringify(clients))}
    />
  )
}
