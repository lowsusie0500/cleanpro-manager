'use client'

import { useState, useRef } from 'react'
import { format } from 'date-fns'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

export function DailyReportClient({ reports: initial, staff, clients }: any) {
  const { lang } = useLanguageStore()
  const [reports, setReports] = useState(initial)
  const [submitting, setSubmitting] = useState(false)
  const [photos, setPhotos] = useState<string[]>([])
  const fileRef = useRef<HTMLInputElement>(null)

  const [form, setForm] = useState({
    staffId: staff[0]?.id ?? '',
    date: new Date().toISOString().split('T')[0],
    clientName: clients[0]?.name ?? '',
    cashReceived: '',
    notes: '',
  })

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? [])
    files.forEach(f => {
      const reader = new FileReader()
      reader.onload = ev => setPhotos(prev => [...prev, ev.target?.result as string])
      reader.readAsDataURL(f)
    })
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitting(true)
    try {
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          cashReceived: parseFloat(form.cashReceived) || 0,
          photos: JSON.stringify(photos),
          submitted: true,
        }),
      })
      const newReport = await res.json()
      setReports((prev: any[]) => [newReport, ...prev])
      setForm({ ...form, cashReceived: '', notes: '' })
      setPhotos([])
      alert(lang === 'zh' ? '报告已提交！✅' : 'Report submitted! ✅')
    } catch (e) {
      alert('Error submitting report')
    }
    setSubmitting(false)
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl lg:text-2xl font-bold">{t('dailyReport', lang)}</h1>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        {/* Form */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="font-semibold text-sm mb-4">{t('submitReport', lang)}</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('date', lang)}</label>
                <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('driver', lang)}</label>
                <select value={form.staffId} onChange={e => setForm({ ...form, staffId: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                  {staff.map((s: any) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">Client</label>
              <select value={form.clientName} onChange={e => setForm({ ...form, clientName: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]">
                {clients.map((c: any) => <option key={c.id} value={c.name}>{c.name}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('cashReceived', lang)}</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-gray-500">RM</span>
                <input type="number" step="0.01" min="0" value={form.cashReceived}
                  onChange={e => setForm({ ...form, cashReceived: e.target.value })}
                  placeholder="0.00"
                  className="w-full pl-10 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C]" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('notes', lang)}</label>
              <textarea rows={3} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })}
                placeholder={lang === 'zh' ? '任何备注...' : 'Any remarks, issues, or special notes...'}
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none" />
            </div>

            {/* Photo upload */}
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1.5">{t('uploadExpenses', lang)}</label>
              <div
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed border-gray-200 rounded-lg p-5 text-center cursor-pointer hover:border-[#0F4C5C] hover:bg-blue-50/30 transition-all">
                <div className="text-3xl mb-1">📷</div>
                <p className="text-sm text-gray-500">{t('tapToUpload', lang)}</p>
                <p className="text-xs text-gray-400 mt-0.5">JPEG, PNG up to 10MB each</p>
              </div>
              <input ref={fileRef} type="file" multiple accept="image/*" className="hidden" onChange={handlePhotoChange} />
              {photos.length > 0 && (
                <div className="grid grid-cols-4 gap-2 mt-2">
                  {photos.map((p, i) => (
                    <div key={i} className="relative group">
                      <img src={p} alt="" className="w-full h-16 object-cover rounded-lg" />
                      <button type="button" onClick={() => setPhotos(prev => prev.filter((_, j) => j !== i))}
                        className="absolute top-1 right-1 bg-black/60 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center opacity-0 group-hover:opacity-100">
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button type="submit" disabled={submitting}
              className="w-full py-2.5 bg-[#0F4C5C] hover:bg-[#1a6b80] text-white font-semibold rounded-lg text-sm transition-colors disabled:opacity-60">
              {submitting ? '...' : `✓ ${t('submitReport', lang)}`}
            </button>
          </form>
        </div>

        {/* Recent Reports */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="font-semibold text-sm mb-4">{t('recentReports', lang)}</h2>
          <div className="space-y-0">
            {reports.length === 0 && (
              <div className="text-center py-10 text-gray-400">
                <p className="text-3xl mb-2">📝</p>
                <p className="text-sm">No reports yet</p>
              </div>
            )}
            {reports.map((r: any) => (
              <div key={r.id} className="flex items-start gap-3 py-3 border-b border-gray-100 last:border-0">
                <div className="w-8 h-8 rounded-full bg-[#0F4C5C] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {r.staff?.name?.[0] ?? '?'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline justify-between">
                    <span className="font-semibold text-sm">{r.staff?.name}</span>
                    <span className="text-xs text-gray-400">{format(new Date(r.createdAt), 'dd MMM')}</span>
                  </div>
                  <p className="text-xs text-gray-500 truncate">{r.clientName}</p>
                  {r.notes && <p className="text-xs text-gray-600 mt-0.5 italic">"{r.notes}"</p>}
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-bold text-sm text-green-600">RM {r.cashReceived}</p>
                  {r.submitted && <span className="text-xs text-green-500">✓ Submitted</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
