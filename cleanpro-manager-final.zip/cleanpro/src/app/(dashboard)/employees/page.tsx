import { prisma } from '@/lib/prisma'
import { EmployeesClient } from './EmployeesClient'

export default async function EmployeesPage() {
  const staff = await prisma.staff.findMany({ orderBy: { name: 'asc' } })
  return <EmployeesClient staff={JSON.parse(JSON.stringify(staff))} />
}
