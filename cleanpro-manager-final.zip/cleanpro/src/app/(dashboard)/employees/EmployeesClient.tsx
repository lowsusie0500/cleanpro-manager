'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { STAFF_COLORS } from '@/lib/constants'
import { AddStaffModal } from '@/components/modals/AddStaffModal'
import { EditStaffModal } from '@/components/modals/EditStaffModal'

export function EmployeesClient({ staff: initial }: { staff: any[] }) {
  const { lang } = useLanguageStore()
  const [staff, setStaff] = useState(initial)
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingStaff, setEditingStaff] = useState<any | null>(null)
  const [toast, setToast] = useState('')

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  function handleAdded(s: any) {
    setStaff(prev => [...prev, s])
    setShowAddModal(false)
    showToast(lang === 'zh' ? '员工已添加 ✓' : 'Staff added ✓')
  }

  function handleUpdated(updated: any) {
    setStaff(prev => prev.map(s => s.id === updated.id ? updated : s))
    setEditingStaff(null)
    showToast(lang === 'zh' ? '已保存 ✓' : 'Saved ✓')
  }

  async function handleToggleStatus(emp: any) {
    const newStatus = emp.status === 'active' ? 'inactive' : 'active'
    const res = await fetch(`/api/staff/${emp.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus }),
    })
    if (res.ok) {
      setStaff(prev => prev.map(s => s.id === emp.id ? { ...s, status: newStatus } : s))
      showToast(`${emp.name} ${newStatus === 'active' ? 'activated' : 'deactivated'} ✓`)
    }
  }

  return (
    <div>
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 lg:bottom-6 right-4 z-[200] bg-green-600 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-lg">
          {toast}
        </div>
      )}

      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl lg:text-2xl font-bold">{t('employees', lang)}</h1>
        <button onClick={() => setShowAddModal(true)}
          className="px-3 py-2 text-sm bg-[#0F4C5C] hover:bg-[#1a6b80] text-white font-semibold rounded-lg transition-colors">
          + {t('addStaff', lang)}
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr>
                <th>{t('name', lang)}</th>
                <th>{t('role', lang)}</th>
                <th>Phone</th>
                <th>{t('area', lang)}</th>
                <th>{t('status', lang)}</th>
                <th>{t('actions', lang)}</th>
              </tr>
            </thead>
            <tbody>
              {staff.map(emp => (
                <tr key={emp.id} className={emp.status !== 'active' ? 'opacity-60' : ''}>
                  <td>
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0"
                        style={{ backgroundColor: STAFF_COLORS[emp.colorCode as keyof typeof STAFF_COLORS] ?? '#999' }}>
                        {emp.name[0]}
                      </div>
                      <div>
                        <div className="font-semibold text-sm">{emp.name}</div>
                        {emp.icNumber && <div className="text-xs text-gray-400">{emp.icNumber}</div>}
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${emp.role === 'driver' ? 'badge-blue' : emp.role === 'supervisor' ? 'badge-purple' : 'badge-green'}`}>
                      {emp.role}
                    </span>
                  </td>
                  <td className="text-sm">{emp.phone}</td>
                  <td className="text-sm text-gray-600">{emp.area}</td>
                  <td>
                    <span className={`badge ${emp.status === 'active' ? 'badge-green' : emp.status === 'leave' ? 'badge-yellow' : 'badge-gray'}`}>
                      {emp.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setEditingStaff(emp)}
                        className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-[#0F4C5C] hover:text-[#0F4C5C] transition-colors">
                        ✏️ Edit
                      </button>
                      <button
                        onClick={() => handleToggleStatus(emp)}
                        className={`text-xs px-2 py-1 border rounded transition-colors ${
                          emp.status === 'active'
                            ? 'border-gray-200 hover:border-red-400 hover:text-red-500'
                            : 'border-gray-200 hover:border-green-500 hover:text-green-600'
                        }`}>
                        {emp.status === 'active' ? '⏸' : '▶'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {staff.length === 0 && (
                <tr><td colSpan={6} className="text-center py-10 text-gray-400">No staff found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && <AddStaffModal onClose={() => setShowAddModal(false)} onSaved={handleAdded} />}
      {editingStaff && (
        <EditStaffModal
          employee={editingStaff}
          onClose={() => setEditingStaff(null)}
          onSaved={handleUpdated}
        />
      )}
    </div>
  )
}
