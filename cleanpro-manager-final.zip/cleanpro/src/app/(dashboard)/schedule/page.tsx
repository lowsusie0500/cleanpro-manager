import { prisma } from '@/lib/prisma'
import { ScheduleClient } from './ScheduleClient'
import { startOfWeek, endOfWeek, addWeeks } from 'date-fns'

export default async function SchedulePage({
  searchParams,
}: {
  searchParams: { week?: string }
}) {
  const weekOffset = parseInt(searchParams.week ?? '0')
  const now = new Date()
  const weekStart = startOfWeek(addWeeks(now, weekOffset), { weekStartsOn: 1 })
  const weekEnd = endOfWeek(addWeeks(now, weekOffset), { weekStartsOn: 1 })

  const [staff, jobs] = await Promise.all([
    prisma.staff.findMany({ where: { status: 'active' }, orderBy: { name: 'asc' } }),
    prisma.job.findMany({
      where: { date: { gte: weekStart, lte: weekEnd } },
      include: { client: true, staff: true },
    }),
  ])

  const clients = await prisma.client.findMany({
    where: { status: 'active' },
    select: { id: true, name: true, area: true },
    orderBy: { name: 'asc' },
  })

  return (
    <ScheduleClient
      staff={JSON.parse(JSON.stringify(staff))}
      jobs={JSON.parse(JSON.stringify(jobs))}
      clients={JSON.parse(JSON.stringify(clients))}
      weekOffset={weekOffset}
      weekStart={weekStart.toISOString()}
    />
  )
}
