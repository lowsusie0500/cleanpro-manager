'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { format, addDays, parseISO } from 'date-fns'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { STAFF_COLORS, COLOR_CLASSES } from '@/lib/constants'
import { AddJobModal } from '@/components/modals/AddJobModal'
import { EditJobModal } from '@/components/modals/EditJobModal'

const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

interface Props {
  staff: any[]
  jobs: any[]
  clients: any[]
  weekOffset: number
  weekStart: string
}

export function ScheduleClient({ staff, jobs, clients, weekOffset, weekStart }: Props) {
  const { lang } = useLanguageStore()
  const router = useRouter()
  const [schedType, setSchedType] = useState<'weekly' | 'biweekly' | 'custom'>('weekly')
  const [localJobs, setLocalJobs] = useState(jobs)
  const [dragJobId, setDragJobId] = useState<string | null>(null)
  const [dragOver, setDragOver] = useState<string | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [addModalDefaults, setAddModalDefaults] = useState<{ staffId?: string; date?: string }>({})
  const [editingJob, setEditingJob] = useState<any | null>(null)
  const [toast, setToast] = useState('')

  const weekStartDate = parseISO(weekStart)
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStartDate, i))

  const displayStaff = schedType === 'biweekly'
    ? staff.filter((_, i) => i % 2 === (Math.abs(weekOffset) % 2))
    : staff

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  function getJobsForCell(staffId: string, dayIndex: number) {
    const dayDate = days[dayIndex]
    return localJobs.filter(j => {
      const jDate = new Date(j.date)
      return j.staffId === staffId && jDate.toDateString() === dayDate.toDateString()
    })
  }

  async function handleDrop(staffId: string, dayIndex: number, jobId: string) {
    const newDate = days[dayIndex].toISOString()
    setLocalJobs(prev => prev.map(j =>
      j.id === jobId
        ? { ...j, staffId, date: newDate, staff: staff.find(s => s.id === staffId) }
        : j
    ))
    setDragOver(null)
    try {
      await fetch(`/api/jobs/${jobId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ staffId, date: newDate }),
      })
      showToast('Job moved ✓')
    } catch (e) { console.error(e) }
  }

  async function handleDeleteJob(jobId: string) {
    if (!confirm(lang === 'zh' ? '确认删除此工作？' : 'Remove this job?')) return
    setLocalJobs(prev => prev.filter(j => j.id !== jobId))
    try {
      await fetch(`/api/jobs/${jobId}`, { method: 'DELETE' })
      showToast('Job removed ✓')
    } catch (e) { console.error(e) }
  }

  function openAddModal(staffId?: string, date?: string) {
    setAddModalDefaults({ staffId, date })
    setShowAddModal(true)
  }

  function handleJobAdded(newJob: any) {
    // Attach full client/staff objects for immediate display
    const enriched = {
      ...newJob,
      client: clients.find(c => c.id === newJob.clientId) ?? newJob.client,
      staff:  staff.find(s => s.id === newJob.staffId)   ?? newJob.staff,
    }
    setLocalJobs(prev => [...prev, enriched])
    setShowAddModal(false)
    showToast(lang === 'zh' ? '工作已添加 ✓' : 'Job added ✓')
  }

  function handleJobUpdated(updated: any) {
    const enriched = {
      ...updated,
      client: clients.find(c => c.id === updated.clientId) ?? updated.client,
      staff:  staff.find(s => s.id === updated.staffId)   ?? updated.staff,
    }
    setLocalJobs(prev => prev.map(j => j.id === updated.id ? enriched : j))
    setEditingJob(null)
    showToast(lang === 'zh' ? '已保存 ✓' : 'Saved ✓')
  }

  function exportSchedule() {
    const rows = [['Staff', 'Client', 'Date', 'Start', 'End', 'Status', 'Notes']]
    localJobs.forEach(j => {
      rows.push([
        j.staff?.name ?? '',
        j.client?.name ?? '',
        new Date(j.date).toLocaleDateString(),
        j.startTime,
        j.endTime,
        j.status,
        j.notes ?? '',
      ])
    })
    const csv = rows.map(r => r.map(v => `"${v}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `schedule-${format(days[0], 'yyyy-MM-dd')}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div>
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 lg:bottom-6 right-4 z-[200] bg-green-600 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-lg animate-in slide-in-from-right-4">
          {toast}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h1 className="text-xl lg:text-2xl font-bold">{t('schedule', lang)}</h1>
        <div className="flex gap-2">
          <button
            onClick={exportSchedule}
            className="px-3 py-2 text-sm border border-gray-200 rounded-lg hover:border-[#0F4C5C] transition-colors">
            📤 {t('export', lang)}
          </button>
          <button
            onClick={() => openAddModal()}
            className="px-3 py-2 text-sm bg-amber-400 hover:bg-amber-500 text-gray-800 font-semibold rounded-lg transition-colors">
            + {t('addJob', lang)}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-4">
        {/* Toolbar */}
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <div className="flex rounded-lg border border-gray-200 overflow-hidden">
            {(['weekly', 'biweekly', 'custom'] as const).map(type => (
              <button key={type}
                onClick={() => setSchedType(type)}
                className={`px-3 py-1.5 text-xs font-medium transition-colors ${schedType === type ? 'bg-[#0F4C5C] text-white' : 'hover:bg-gray-50 text-gray-600'}`}>
                {type === 'weekly' ? 'Weekly' : type === 'biweekly' ? 'Bi-Weekly' : 'Custom'}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button onClick={() => router.push(`/schedule?week=${weekOffset - 1}`)}
              className="w-7 h-7 flex items-center justify-center border border-gray-200 rounded-lg text-gray-600 hover:border-[#0F4C5C] transition-colors text-lg">
              ‹
            </button>
            <span className="text-sm font-semibold min-w-[200px] text-center">
              {format(days[0], 'd MMM')} – {format(days[6], 'd MMM yyyy')}
            </span>
            <button onClick={() => router.push(`/schedule?week=${weekOffset + 1}`)}
              className="w-7 h-7 flex items-center justify-center border border-gray-200 rounded-lg text-gray-600 hover:border-[#0F4C5C] transition-colors text-lg">
              ›
            </button>
          </div>

          <button onClick={() => router.push('/schedule?week=0')}
            className="px-3 py-1.5 text-xs border border-gray-200 rounded-lg hover:border-[#0F4C5C] transition-colors">
            {t('today', lang)}
          </button>
        </div>

        {/* Schedule Grid */}
        <div className="overflow-x-auto">
          <div style={{ minWidth: 800 }}>
            {/* Header row */}
            <div className="grid" style={{ gridTemplateColumns: '110px repeat(7, 1fr)' }}>
              <div className="bg-[#0F4C5C] text-white text-xs font-semibold px-3 py-2.5 rounded-tl-lg">
                Staff
              </div>
              {days.map((day, i) => {
                const isToday = day.toDateString() === new Date().toDateString()
                return (
                  <div key={i}
                    className={`text-xs font-semibold px-2 py-2.5 text-center border-l border-white/20 ${isToday ? 'bg-amber-400 text-gray-800' : 'bg-[#0F4C5C] text-white'} ${i === 6 ? 'rounded-tr-lg' : ''}`}>
                    <div className="font-bold">{DAY_NAMES[i]}</div>
                    <div className="opacity-75">{format(day, 'd MMM')}</div>
                  </div>
                )
              })}
            </div>

            {/* Staff rows */}
            {displayStaff.map(emp => (
              <div key={emp.id}
                className="grid border-t border-gray-100"
                style={{ gridTemplateColumns: '110px repeat(7, 1fr)' }}>

                {/* Staff label */}
                <div className="bg-gray-50 px-3 py-2 flex items-center gap-2 border-r border-gray-100">
                  <div className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ backgroundColor: STAFF_COLORS[emp.colorCode as keyof typeof STAFF_COLORS] ?? '#999' }} />
                  <span className="text-xs font-semibold text-gray-700 truncate">{emp.name}</span>
                </div>

                {/* Day cells */}
                {days.map((day, dayIdx) => {
                  const cellKey = `${emp.id}-${dayIdx}`
                  const cellJobs = getJobsForCell(emp.id, dayIdx)
                  const isOver = dragOver === cellKey

                  return (
                    <div key={dayIdx}
                      className={`min-h-[72px] p-1 border-l border-gray-100 transition-colors ${isOver ? 'bg-blue-50 outline outline-2 outline-dashed outline-blue-300' : 'bg-white hover:bg-gray-50/50'}`}
                      onDragOver={e => { e.preventDefault(); setDragOver(cellKey) }}
                      onDragLeave={() => setDragOver(null)}
                      onDrop={e => {
                        e.preventDefault()
                        const jobId = e.dataTransfer.getData('jobId')
                        if (jobId) handleDrop(emp.id, dayIdx, jobId)
                      }}>

                      {cellJobs.map(job => {
                        const colorKey = (job.staff?.colorCode ?? emp.colorCode) as string
                        return (
                          <div key={job.id}
                            draggable
                            onDragStart={e => { e.dataTransfer.setData('jobId', job.id); setDragJobId(job.id) }}
                            onDragEnd={() => setDragJobId(null)}
                            className={`sch-block ${COLOR_CLASSES[colorKey] ?? 'sch-block-teal'} ${dragJobId === job.id ? 'opacity-40' : ''} group`}>
                            <div className="text-[10px] opacity-70">{job.startTime}–{job.endTime}</div>
                            <div className="font-semibold text-[11px] truncate pr-8">{job.client?.name}</div>
                            {job.status && job.status !== 'scheduled' && (
                              <div className="text-[9px] opacity-60 capitalize">{job.status}</div>
                            )}
                            {/* Action buttons shown on hover */}
                            <div className="absolute top-1 right-1 hidden group-hover:flex gap-0.5">
                              <button
                                onClick={e => { e.stopPropagation(); setEditingJob(job) }}
                                className="text-[10px] text-gray-500 hover:text-[#0F4C5C] leading-none px-0.5"
                                title="Edit">
                                ✏️
                              </button>
                              <button
                                onClick={e => { e.stopPropagation(); handleDeleteJob(job.id) }}
                                className="text-[10px] text-gray-500 hover:text-red-500 leading-none px-0.5"
                                title="Delete">
                                ✕
                              </button>
                            </div>
                          </div>
                        )
                      })}

                      <button
                        onClick={() => openAddModal(emp.id, day.toISOString())}
                        className="w-full mt-1 border border-dashed border-gray-200 rounded text-gray-300 hover:text-[#0F4C5C] hover:border-[#0F4C5C] hover:bg-blue-50/50 text-sm py-0.5 transition-colors">
                        +
                      </button>
                    </div>
                  )
                })}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-3 mt-3">
        {staff.map(emp => (
          <div key={emp.id} className="flex items-center gap-1.5 text-xs text-gray-600">
            <div className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: STAFF_COLORS[emp.colorCode as keyof typeof STAFF_COLORS] ?? '#999' }} />
            {emp.name}
          </div>
        ))}
      </div>

      {/* Modals */}
      {showAddModal && (
        <AddJobModal
          staff={staff}
          clients={clients}
          defaultStaffId={addModalDefaults.staffId}
          defaultDate={addModalDefaults.date}
          onClose={() => setShowAddModal(false)}
          onSaved={handleJobAdded}
        />
      )}
      {editingJob && (
        <EditJobModal
          job={editingJob}
          staff={staff}
          clients={clients}
          onClose={() => setEditingJob(null)}
          onSaved={handleJobUpdated}
        />
      )}
    </div>
  )
}
