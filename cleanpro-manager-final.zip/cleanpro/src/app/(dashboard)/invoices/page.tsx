import { prisma } from '@/lib/prisma'
import { InvoicesClient } from './InvoicesClient'

export default async function InvoicesPage() {
  const [invoices, clients] = await Promise.all([
    prisma.invoice.findMany({
      include: { client: true, items: true },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.client.findMany({ where: { status: 'active' }, select: { id: true, name: true } }),
  ])
  return (
    <InvoicesClient
      invoices={JSON.parse(JSON.stringify(invoices))}
      clients={JSON.parse(JSON.stringify(clients))}
    />
  )
}
