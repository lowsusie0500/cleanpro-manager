'use client'

import { useState } from 'react'
import { format } from 'date-fns'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { AddInvoiceModal } from '@/components/modals/AddInvoiceModal'
import { EditInvoiceModal } from '@/components/modals/EditInvoiceModal'
import { InvoicePreview } from '@/components/InvoicePreview'

const STATUS_BADGE: Record<string, string> = {
  paid: 'badge-green', pending: 'badge-yellow', overdue: 'badge-red', cancelled: 'badge-gray',
}

export function InvoicesClient({ invoices: initial, clients }: { invoices: any[]; clients: any[] }) {
  const { lang } = useLanguageStore()
  const [invoices, setInvoices] = useState(initial)
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingInvoice, setEditingInvoice] = useState<any | null>(null)
  const [previewInvoice, setPreviewInvoice] = useState<any>(null)
  const [toast, setToast] = useState('')

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  function handleAdded(inv: any) {
    setInvoices(prev => [inv, ...prev])
    setShowAddModal(false)
    showToast(lang === 'zh' ? '发票已创建 ✓' : 'Invoice created ✓')
  }

  function handleUpdated(updated: any) {
    setInvoices(prev => prev.map(i => i.id === updated.id ? updated : i))
    setEditingInvoice(null)
    showToast(lang === 'zh' ? '已保存 ✓' : 'Saved ✓')
  }

  async function markPaid(id: string) {
    const res = await fetch(`/api/invoices/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'paid' }),
    })
    if (res.ok) {
      const updated = await res.json()
      setInvoices(prev => prev.map(i => i.id === id ? { ...i, ...updated } : i))
      showToast(lang === 'zh' ? '已标记为已付 ✓' : 'Marked as paid ✓')
    }
  }

  async function handleDelete(id: string) {
    if (!confirm(lang === 'zh' ? '确认取消此发票？' : 'Cancel this invoice?')) return
    const res = await fetch(`/api/invoices/${id}`, { method: 'DELETE' })
    if (res.ok) {
      setInvoices(prev => prev.map(i => i.id === id ? { ...i, status: 'cancelled' } : i))
      showToast(lang === 'zh' ? '发票已取消' : 'Invoice cancelled')
    }
  }

  const stats = [
    { label: 'Total',   value: invoices.length,                                           color: 'border-blue-400' },
    { label: 'Pending', value: invoices.filter(i => i.status === 'pending').length,       color: 'border-yellow-400' },
    { label: 'Paid',    value: invoices.filter(i => i.status === 'paid').length,          color: 'border-green-400' },
    { label: 'Overdue', value: invoices.filter(i => i.status === 'overdue').length,       color: 'border-red-400' },
  ]

  return (
    <div>
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 lg:bottom-6 right-4 z-[200] bg-green-600 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-lg">
          {toast}
        </div>
      )}

      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl lg:text-2xl font-bold">{t('invoices', lang)}</h1>
        <button onClick={() => setShowAddModal(true)}
          className="px-3 py-2 text-sm bg-[#0F4C5C] hover:bg-[#1a6b80] text-white font-semibold rounded-lg transition-colors">
          + {lang === 'zh' ? '新建发票' : 'New Invoice'}
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {stats.map(s => (
          <div key={s.label} className={`bg-white rounded-xl p-4 border-t-4 ${s.color} shadow-sm text-center`}>
            <h3 className="text-2xl font-bold">{s.value}</h3>
            <p className="text-xs text-gray-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Client</th>
                <th>Amount</th>
                <th>Due Date</th>
                <th>{t('status', lang)}</th>
                <th>{t('actions', lang)}</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map(inv => (
                <tr key={inv.id}>
                  <td>
                    <span className="font-semibold text-sm text-[#0F4C5C]">{inv.number}</span>
                  </td>
                  <td className="text-sm">{inv.client?.name}</td>
                  <td>
                    <span className="font-bold text-sm">RM {Number(inv.total).toLocaleString()}</span>
                  </td>
                  <td className="text-sm">{format(new Date(inv.dueDate), 'dd MMM yyyy')}</td>
                  <td>
                    <span className={`badge ${STATUS_BADGE[inv.status] ?? 'badge-gray'}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-1.5 flex-wrap">
                      <button
                        onClick={() => setPreviewInvoice(inv)}
                        className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-[#0F4C5C] transition-colors">
                        👁 View
                      </button>
                      <button
                        onClick={() => setEditingInvoice(inv)}
                        className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-[#0F4C5C] hover:text-[#0F4C5C] transition-colors">
                        ✏️ Edit
                      </button>
                      {inv.status !== 'paid' && inv.status !== 'cancelled' && (
                        <button
                          onClick={() => markPaid(inv.id)}
                          className="text-xs px-2 py-1 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">
                          ✓ Paid
                        </button>
                      )}
                      {inv.status !== 'cancelled' && (
                        <button
                          onClick={() => handleDelete(inv.id)}
                          className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-red-400 hover:text-red-500 transition-colors">
                          🗑
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {invoices.length === 0 && (
                <tr><td colSpan={6} className="text-center py-10 text-gray-400">No invoices yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <AddInvoiceModal clients={clients} onClose={() => setShowAddModal(false)} onSaved={handleAdded} />
      )}
      {editingInvoice && (
        <EditInvoiceModal
          invoice={editingInvoice}
          clients={clients}
          onClose={() => setEditingInvoice(null)}
          onSaved={handleUpdated}
        />
      )}
      {previewInvoice && (
        <InvoicePreview invoice={previewInvoice} onClose={() => setPreviewInvoice(null)} />
      )}
    </div>
  )
}
