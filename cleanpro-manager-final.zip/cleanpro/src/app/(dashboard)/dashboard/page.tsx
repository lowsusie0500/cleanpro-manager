import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { DashboardClient } from './DashboardClient'
import { startOfDay, endOfDay, startOfMonth, endOfMonth } from 'date-fns'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  const now = new Date()

  const [todayJobs, monthlyPayments, activeClients, pendingInvoices, recentActivity] = await Promise.all([
    prisma.job.findMany({
      where: { date: { gte: startOfDay(now), lte: endOfDay(now) } },
      include: { client: true, staff: true },
      orderBy: { startTime: 'asc' },
    }),
    prisma.payment.aggregate({
      where: { date: { gte: startOfMonth(now), lte: endOfMonth(now) } },
      _sum: { amount: true },
    }),
    prisma.client.count({ where: { status: 'active' } }),
    prisma.invoice.findMany({
      where: { status: { in: ['pending', 'overdue'] } },
      include: { client: true },
      orderBy: { dueDate: 'asc' },
      take: 5,
    }),
    prisma.dailyReport.findMany({
      include: { staff: true },
      orderBy: { createdAt: 'desc' },
      take: 8,
    }),
  ])

  return (
    <DashboardClient
      todayJobs={JSON.parse(JSON.stringify(todayJobs))}
      monthlyRevenue={monthlyPayments._sum.amount ?? 0}
      activeClients={activeClients}
      pendingInvoices={JSON.parse(JSON.stringify(pendingInvoices))}
      recentActivity={JSON.parse(JSON.stringify(recentActivity))}
      userName={session?.user?.name ?? 'Admin'}
    />
  )
}
