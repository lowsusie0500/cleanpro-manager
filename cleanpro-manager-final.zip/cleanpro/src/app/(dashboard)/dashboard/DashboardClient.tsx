'use client'

import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { format } from 'date-fns'
import { STAFF_COLORS } from '@/lib/constants'
import { RevenueChart } from '@/components/charts/RevenueChart'
import Link from 'next/link'

interface Props {
  todayJobs: any[]
  monthlyRevenue: number
  activeClients: number
  pendingInvoices: any[]
  recentActivity: any[]
  userName: string
}

export function DashboardClient({ todayJobs, monthlyRevenue, activeClients, pendingInvoices, recentActivity, userName }: Props) {
  const { lang } = useLanguageStore()
  const today = new Date()

  const stats = [
    { label: t('todayJobs', lang), value: todayJobs.length, icon: '📋', color: 'bg-blue-50', trend: `${todayJobs.filter(j => j.status === 'completed').length} completed` },
    { label: t('monthlyRev', lang), value: `RM ${monthlyRevenue.toLocaleString()}`, icon: '💰', color: 'bg-green-50', trend: '↑ vs last month' },
    { label: t('activeClients', lang), value: activeClients, icon: '👥', color: 'bg-amber-50', trend: 'Total active' },
    { label: t('pendingInvoices', lang), value: pendingInvoices.length, icon: '🧾', color: 'bg-red-50', trend: `RM ${pendingInvoices.reduce((s, i) => s + i.total, 0).toLocaleString()} outstanding` },
  ]

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl lg:text-2xl font-bold text-gray-900">
            {t('dashboard', lang)}
          </h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {format(today, 'EEEE, d MMMM yyyy')}
          </p>
        </div>
        <div className="hidden lg:flex gap-2">
          <Link href="/schedule" className="px-3 py-2 text-sm border border-gray-200 rounded-lg hover:border-[#0F4C5C] hover:text-[#0F4C5C] transition-colors">
            📅 {t('viewSchedule', lang)}
          </Link>
          <Link href="/schedule" className="px-3 py-2 text-sm bg-amber-400 text-gray-800 rounded-lg font-semibold hover:bg-amber-500 transition-colors">
            + {t('addJob', lang)}
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-6">
        {stats.map((s, i) => (
          <div key={i} className="stat-card">
            <div className={`w-11 h-11 ${s.color} rounded-xl flex items-center justify-center text-xl flex-shrink-0`}>
              {s.icon}
            </div>
            <div>
              <p className="text-xs text-gray-500 font-medium">{s.label}</p>
              <h3 className="text-xl lg:text-2xl font-bold mt-0.5">{s.value}</h3>
              <p className="text-xs text-green-600 mt-0.5">{s.trend}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-2 gap-4 mb-4">
        {/* Today's Schedule */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold">{t('todaySchedule', lang)}</h2>
            <Link href="/schedule" className="text-xs text-[#0F4C5C] hover:underline">{t('viewAll', lang)}</Link>
          </div>
          {todayJobs.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p className="text-3xl mb-2">📅</p>
              <p className="text-sm">{lang === 'zh' ? '今日无工作安排' : 'No jobs scheduled today'}</p>
            </div>
          ) : (
            <div className="space-y-0">
              {todayJobs.slice(0, 6).map((job, i) => (
                <div key={job.id} className="flex items-center gap-3 py-2.5 border-b border-gray-100 last:border-0">
                  <div className={`w-2 h-2 rounded-full flex-shrink-0`}
                    style={{ backgroundColor: STAFF_COLORS[job.staff?.colorCode as keyof typeof STAFF_COLORS] ?? '#999' }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{job.client?.name}</p>
                    <p className="text-xs text-gray-500">{job.staff?.name} · {job.startTime}–{job.endTime}</p>
                  </div>
                  <span className={`badge ${job.status === 'completed' ? 'badge-green' : 'badge-blue'} text-xs`}>
                    {job.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pending Invoices */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold">{t('pendingInvoices', lang)}</h2>
            <Link href="/invoices" className="text-xs text-[#0F4C5C] hover:underline">{t('viewAll', lang)}</Link>
          </div>
          {pendingInvoices.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p className="text-3xl mb-2">✅</p>
              <p className="text-sm">{lang === 'zh' ? '没有待付发票' : 'No pending invoices'}</p>
            </div>
          ) : (
            <div className="space-y-0">
              {pendingInvoices.map((inv) => (
                <div key={inv.id} className="flex items-center gap-3 py-2.5 border-b border-gray-100 last:border-0">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold">{inv.number}</p>
                    <p className="text-xs text-gray-500">{inv.client?.name} · Due {format(new Date(inv.dueDate), 'dd MMM')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">RM {inv.total.toLocaleString()}</p>
                    <span className={`badge ${inv.status === 'overdue' ? 'badge-red' : 'badge-yellow'} text-xs`}>
                      {inv.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-white rounded-xl shadow-sm p-5">
        <h2 className="text-sm font-semibold mb-4">{lang === 'zh' ? '收入概览' : 'Revenue Overview'}</h2>
        <RevenueChart />
      </div>
    </div>
  )
}
