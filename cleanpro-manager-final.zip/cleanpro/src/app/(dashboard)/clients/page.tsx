import { prisma } from '@/lib/prisma'
import { ClientsClient } from './ClientsClient'

export default async function ClientsPage() {
  const [clients, staff] = await Promise.all([
    prisma.client.findMany({
      orderBy: { createdAt: 'desc' },
    }),
    prisma.staff.findMany({ where: { status: 'active' }, select: { id: true, name: true } }),
  ])

  return (
    <ClientsClient
      clients={JSON.parse(JSON.stringify(clients))}
      staff={JSON.parse(JSON.stringify(staff))}
    />
  )
}
