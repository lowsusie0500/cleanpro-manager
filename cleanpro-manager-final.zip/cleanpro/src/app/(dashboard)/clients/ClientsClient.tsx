'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { AddClientModal } from '@/components/modals/AddClientModal'
import { EditClientModal } from '@/components/modals/EditClientModal'

const FREQ_BADGE: Record<string, string> = {
  weekly: 'badge-green', biweekly: 'badge-blue', monthly: 'badge-yellow', once: 'badge-gray',
}

export function ClientsClient({ clients: initial, staff }: { clients: any[]; staff: any[] }) {
  const { lang } = useLanguageStore()
  const [clients, setClients] = useState(initial)
  const [search, setSearch] = useState('')
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingClient, setEditingClient] = useState<any | null>(null)
  const [toast, setToast] = useState('')

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  const filtered = clients.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.area.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search)
  )

  function handleAdded(newClient: any) {
    setClients(prev => [newClient, ...prev])
    setShowAddModal(false)
    showToast(lang === 'zh' ? '客户已添加 ✓' : 'Client added ✓')
  }

  function handleUpdated(updated: any) {
    setClients(prev => prev.map(c => c.id === updated.id ? updated : c))
    setEditingClient(null)
    showToast(lang === 'zh' ? '已保存 ✓' : 'Saved ✓')
  }

  async function handleDelete(id: string) {
    if (!confirm(lang === 'zh' ? '确认停用此客户？' : 'Deactivate this client?')) return
    const res = await fetch(`/api/clients/${id}`, { method: 'DELETE' })
    if (res.ok) {
      setClients(prev => prev.map(c => c.id === id ? { ...c, status: 'inactive' } : c))
      showToast(lang === 'zh' ? '客户已停用' : 'Client deactivated')
    }
  }

  return (
    <div>
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 lg:bottom-6 right-4 z-[200] bg-green-600 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-lg">
          {toast}
        </div>
      )}

      <div className="flex items-center justify-between mb-5 gap-3 flex-wrap">
        <h1 className="text-xl lg:text-2xl font-bold">{t('clients', lang)}</h1>
        <div className="flex gap-2 flex-1 justify-end">
          <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg px-3 py-2 flex-1 max-w-xs">
            <span className="text-gray-400">🔍</span>
            <input
              className="text-sm outline-none w-full"
              placeholder={lang === 'zh' ? '搜索客户...' : 'Search clients...'}
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <button onClick={() => setShowAddModal(true)}
            className="px-3 py-2 text-sm bg-[#0F4C5C] hover:bg-[#1a6b80] text-white font-semibold rounded-lg transition-colors whitespace-nowrap">
            + {t('addClient', lang)}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr>
                <th>{t('name', lang)}</th>
                <th>Contact</th>
                <th>{t('area', lang)}</th>
                <th>{t('frequency', lang)}</th>
                <th>{t('status', lang)}</th>
                <th>{t('actions', lang)}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id}>
                  <td>
                    <div className="font-semibold text-sm">{c.name}</div>
                    <div className="text-xs text-gray-500 truncate max-w-[160px]">{c.address}</div>
                  </td>
                  <td className="text-sm">
                    <div>{c.phone}</div>
                    {c.email && <div className="text-xs text-gray-400">{c.email}</div>}
                  </td>
                  <td><span className="text-xs bg-gray-100 px-2 py-0.5 rounded">{c.area}</span></td>
                  <td>
                    <span className={`badge ${FREQ_BADGE[c.frequency] ?? 'badge-gray'}`}>
                      {c.frequency}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${c.status === 'active' ? 'badge-green' : 'badge-gray'}`}>
                      {c.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setEditingClient(c)}
                        className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-[#0F4C5C] hover:text-[#0F4C5C] transition-colors">
                        ✏️ Edit
                      </button>
                      <button
                        onClick={() => handleDelete(c.id)}
                        className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-red-400 hover:text-red-500 transition-colors">
                        🗑
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="text-center py-10 text-gray-400">No clients found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <AddClientModal staff={staff} onClose={() => setShowAddModal(false)} onSaved={handleAdded} />
      )}
      {editingClient && (
        <EditClientModal
          client={editingClient}
          staff={staff}
          onClose={() => setEditingClient(null)}
          onSaved={handleUpdated}
        />
      )}
    </div>
  )
}
