import { prisma } from '@/lib/prisma'
import { PaymentsClient } from './PaymentsClient'

export default async function PaymentsPage() {
  const [payments, invoices, clients] = await Promise.all([
    prisma.payment.findMany({
      include: { client: true, invoice: true },
      orderBy: { date: 'desc' },
    }),
    prisma.invoice.findMany({
      where: { status: { in: ['pending', 'overdue'] } },
      include: { client: true },
    }),
    prisma.client.findMany({ where: { status: 'active' }, select: { id: true, name: true } }),
  ])
  return (
    <PaymentsClient
      payments={JSON.parse(JSON.stringify(payments))}
      invoices={JSON.parse(JSON.stringify(invoices))}
      clients={JSON.parse(JSON.stringify(clients))}
    />
  )
}
