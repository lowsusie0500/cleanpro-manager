'use client'

import { useState } from 'react'
import { format } from 'date-fns'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { AddPaymentModal } from '@/components/modals/AddPaymentModal'

const METHOD_ICONS: Record<string, string> = {
  cash: '💵', bank_transfer: '🏦', tng: '📱', duitnow: '📲', card: '💳',
}

const PAYMENT_METHODS = [
  { key: 'cash', label: 'Cash', icon: '💵', desc: 'Record cash received' },
  { key: 'bank_transfer', label: 'Bank Transfer', icon: '🏦', desc: 'TNG / Online banking' },
  { key: 'card', label: 'Card / QR', icon: '💳', desc: 'Credit / DuitNow QR' },
]

export function PaymentsClient({ payments: initial, invoices, clients }: any) {
  const { lang } = useLanguageStore()
  const [payments, setPayments] = useState(initial)
  const [selectedMethod, setSelectedMethod] = useState('cash')
  const [showModal, setShowModal] = useState(false)

  const totalThisMonth = payments
    .filter((p: any) => new Date(p.date).getMonth() === new Date().getMonth())
    .reduce((s: number, p: any) => s + p.amount, 0)

  function handleAdded(p: any) { setPayments((prev: any[]) => [p, ...prev]); setShowModal(false) }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl lg:text-2xl font-bold">{t('payments', lang)}</h1>
        <button onClick={() => setShowModal(true)}
          className="px-3 py-2 text-sm bg-[#0F4C5C] hover:bg-[#1a6b80] text-white font-semibold rounded-lg transition-colors">
          + {lang === 'zh' ? '记录付款' : 'Record Payment'}
        </button>
      </div>

      {/* Payment Methods */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-5">
        {PAYMENT_METHODS.map(m => (
          <div key={m.key}
            onClick={() => setSelectedMethod(m.key)}
            className={`bg-white rounded-xl p-5 border-2 cursor-pointer transition-all shadow-sm text-center ${selectedMethod === m.key ? 'border-[#0F4C5C] bg-blue-50/40' : 'border-transparent hover:border-gray-200'}`}>
            <div className="text-3xl mb-2">{m.icon}</div>
            <h4 className="font-semibold text-sm">{m.label}</h4>
            <p className="text-xs text-gray-500 mt-1">{m.desc}</p>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <p className="text-xs text-gray-500">This Month</p>
          <h3 className="text-xl font-bold mt-1">RM {totalThisMonth.toLocaleString()}</h3>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <p className="text-xs text-gray-500">Cash</p>
          <h3 className="text-xl font-bold mt-1">RM {payments.filter((p: any) => p.method === 'cash').reduce((s: number, p: any) => s + p.amount, 0).toLocaleString()}</h3>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <p className="text-xs text-gray-500">Transfer</p>
          <h3 className="text-xl font-bold mt-1">RM {payments.filter((p: any) => p.method !== 'cash').reduce((s: number, p: any) => s + p.amount, 0).toLocaleString()}</h3>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr><th>Date</th><th>Client</th><th>Invoice</th><th>Amount</th><th>Method</th><th>Reference</th></tr>
            </thead>
            <tbody>
              {payments.map((p: any) => (
                <tr key={p.id}>
                  <td className="text-sm">{format(new Date(p.date), 'dd MMM yyyy')}</td>
                  <td className="text-sm font-medium">{p.client?.name}</td>
                  <td className="text-sm text-gray-500">{p.invoice?.number ?? '—'}</td>
                  <td className="font-bold text-sm">RM {p.amount.toLocaleString()}</td>
                  <td>
                    <span className="text-sm">{METHOD_ICONS[p.method] ?? '💰'} {p.method.replace('_', ' ')}</span>
                  </td>
                  <td className="text-sm text-gray-500">{p.reference ?? '—'}</td>
                </tr>
              ))}
              {payments.length === 0 && (
                <tr><td colSpan={6} className="text-center py-10 text-gray-400">No payment records yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <AddPaymentModal clients={clients} invoices={invoices} onClose={() => setShowModal(false)} onSaved={handleAdded} />
      )}
    </div>
  )
}
