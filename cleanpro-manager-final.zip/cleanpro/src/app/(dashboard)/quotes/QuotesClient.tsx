'use client'

import { useState } from 'react'
import { format } from 'date-fns'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { AddQuoteModal } from '@/components/modals/AddQuoteModal'

const STATUS_BADGE: Record<string, string> = {
  pending: 'badge-yellow', accepted: 'badge-green', rejected: 'badge-red', expired: 'badge-gray',
}

export function QuotesClient({ quotes: initial }: { quotes: any[] }) {
  const { lang } = useLanguageStore()
  const [quotes, setQuotes] = useState(initial)
  const [showModal, setShowModal] = useState(false)

  function handleAdded(q: any) { setQuotes(prev => [q, ...prev]); setShowModal(false) }

  async function updateStatus(id: string, status: string) {
    setQuotes(prev => prev.map(q => q.id === id ? { ...q, status } : q))
    await fetch(`/api/quotes/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl lg:text-2xl font-bold">{t('quotes', lang)}</h1>
        <button onClick={() => setShowModal(true)}
          className="px-3 py-2 text-sm bg-[#0F4C5C] hover:bg-[#1a6b80] text-white font-semibold rounded-lg transition-colors">
          + {lang === 'zh' ? '新建报价单' : 'New Quote'}
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Total', value: quotes.length, color: 'border-blue-400' },
          { label: 'Pending', value: quotes.filter(q => q.status === 'pending').length, color: 'border-yellow-400' },
          { label: 'Accepted', value: quotes.filter(q => q.status === 'accepted').length, color: 'border-green-400' },
          { label: 'Rejected', value: quotes.filter(q => q.status === 'rejected').length, color: 'border-red-400' },
        ].map(s => (
          <div key={s.label} className={`bg-white rounded-xl p-4 border-t-4 ${s.color} shadow-sm text-center`}>
            <h3 className="text-2xl font-bold">{s.value}</h3>
            <p className="text-xs text-gray-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr>
                <th>#</th><th>Client</th><th>Service</th><th>Amount</th><th>Date</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {quotes.map(q => (
                <tr key={q.id}>
                  <td className="font-semibold text-sm text-[#0F4C5C]">{q.number}</td>
                  <td>
                    <div className="font-medium text-sm">{q.clientName}</div>
                    {q.clientPhone && <div className="text-xs text-gray-500">{q.clientPhone}</div>}
                  </td>
                  <td className="text-sm">{q.serviceType}</td>
                  <td className="font-bold text-sm">RM {q.amount.toLocaleString()}</td>
                  <td className="text-sm">{format(new Date(q.createdAt), 'dd MMM yyyy')}</td>
                  <td><span className={`badge ${STATUS_BADGE[q.status]}`}>{q.status}</span></td>
                  <td>
                    <div className="flex gap-1.5">
                      {q.status === 'pending' && (
                        <>
                          <button onClick={() => updateStatus(q.id, 'accepted')}
                            className="text-xs px-2 py-1 bg-green-600 text-white rounded hover:bg-green-700">✓</button>
                          <button onClick={() => updateStatus(q.id, 'rejected')}
                            className="text-xs px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600">✗</button>
                        </>
                      )}
                      <button className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-[#0F4C5C]">✏️</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && <AddQuoteModal onClose={() => setShowModal(false)} onSaved={handleAdded} />}
    </div>
  )
}
