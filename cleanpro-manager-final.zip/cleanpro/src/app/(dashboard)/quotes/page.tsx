import { prisma } from '@/lib/prisma'
import { QuotesClient } from './QuotesClient'

export default async function QuotesPage() {
  const quotes = await prisma.quote.findMany({ orderBy: { createdAt: 'desc' } })
  return <QuotesClient quotes={JSON.parse(JSON.stringify(quotes))} />
}
