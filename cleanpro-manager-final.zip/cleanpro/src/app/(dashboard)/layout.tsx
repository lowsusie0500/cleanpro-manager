import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { Sidebar } from '@/components/layout/Sidebar'
import { MobileNav } from '@/components/layout/MobileNav'
import { MobileHeader } from '@/components/layout/MobileHeader'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  return (
    <div className="min-h-screen bg-[#F0F4F7]">
      <Sidebar user={session.user} />
      <MobileHeader />
      <main className="lg:ml-[240px] p-4 lg:p-6 pb-24 lg:pb-6 min-h-screen">
        <div className="page-enter">{children}</div>
      </main>
      <MobileNav />
    </div>
  )
}
