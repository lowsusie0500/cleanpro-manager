'use client'

import { useState } from 'react'
import { format } from 'date-fns'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'
import { AddExpenseModal } from '@/components/modals/AddExpenseModal'

const CAT_BADGE: Record<string, string> = {
  fuel: 'badge-blue', supplies: 'badge-green', equipment: 'badge-purple',
  transport: 'badge-teal', misc: 'badge-gray',
}

export function ExpensesClient({ expenses: initial, staff }: { expenses: any[]; staff: any[] }) {
  const { lang } = useLanguageStore()
  const [expenses, setExpenses] = useState(initial)
  const [showModal, setShowModal] = useState(false)

  const thisMonth = expenses.filter(e => new Date(e.date).getMonth() === new Date().getMonth())
  const totalMonth = thisMonth.reduce((s, e) => s + e.amount, 0)
  const fuelTotal = expenses.filter(e => e.category === 'fuel').reduce((s, e) => s + e.amount, 0)
  const suppliesTotal = expenses.filter(e => e.category === 'supplies').reduce((s, e) => s + e.amount, 0)

  function handleAdded(e: any) { setExpenses(prev => [e, ...prev]); setShowModal(false) }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl lg:text-2xl font-bold">{t('expenses', lang)}</h1>
        <button onClick={() => setShowModal(true)}
          className="px-3 py-2 text-sm bg-[#0F4C5C] hover:bg-[#1a6b80] text-white font-semibold rounded-lg transition-colors">
          + {lang === 'zh' ? '新增费用' : 'Add Expense'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-5">
        {[
          { label: lang === 'zh' ? '本月总计' : 'This Month', value: `RM ${totalMonth.toLocaleString()}`, icon: '📊' },
          { label: lang === 'zh' ? '燃油/交通' : 'Fuel & Transport', value: `RM ${fuelTotal.toLocaleString()}`, icon: '⛽' },
          { label: lang === 'zh' ? '清洁用品' : 'Supplies', value: `RM ${suppliesTotal.toLocaleString()}`, icon: '🧴' },
        ].map(s => (
          <div key={s.label} className="bg-white rounded-xl p-5 shadow-sm flex items-center gap-4">
            <div className="text-3xl">{s.icon}</div>
            <div>
              <p className="text-xs text-gray-500">{s.label}</p>
              <h3 className="text-xl font-bold mt-0.5">{s.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr><th>Date</th><th>Category</th><th>Description</th><th>Staff</th><th>Amount</th><th>Receipt</th></tr>
            </thead>
            <tbody>
              {expenses.map(e => (
                <tr key={e.id}>
                  <td className="text-sm">{format(new Date(e.date), 'dd MMM yyyy')}</td>
                  <td><span className={`badge ${CAT_BADGE[e.category] ?? 'badge-gray'}`}>{e.category}</span></td>
                  <td className="text-sm">{e.description}</td>
                  <td className="text-sm">{e.staff?.name ?? 'Admin'}</td>
                  <td className="font-bold text-sm">RM {e.amount.toLocaleString()}</td>
                  <td>{e.receiptUrl ? <a href={e.receiptUrl} className="text-[#0F4C5C] text-xs underline">View</a> : <span className="text-gray-400 text-xs">—</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && <AddExpenseModal staff={staff} onClose={() => setShowModal(false)} onSaved={handleAdded} />}
    </div>
  )
}
