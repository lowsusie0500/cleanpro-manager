import { prisma } from '@/lib/prisma'
import { ExpensesClient } from './ExpensesClient'
import { startOfMonth, endOfMonth } from 'date-fns'

export default async function ExpensesPage() {
  const now = new Date()
  const [expenses, staff] = await Promise.all([
    prisma.expense.findMany({
      include: { staff: true },
      orderBy: { date: 'desc' },
    }),
    prisma.staff.findMany({ where: { status: 'active' }, select: { id: true, name: true } }),
  ])
  return (
    <ExpensesClient
      expenses={JSON.parse(JSON.stringify(expenses))}
      staff={JSON.parse(JSON.stringify(staff))}
    />
  )
}
