'use client'

import { useState } from 'react'
import { useLanguageStore } from '@/store/languageStore'
import { t } from '@/lib/i18n'

const TABS = [
  { key: 'general',       label: 'General',       icon: '🌐' },
  { key: 'company',       label: 'Company',        icon: '🏢' },
  { key: 'notifications', label: 'Notifications',  icon: '🔔' },
  { key: 'users',         label: 'Users',          icon: '👤' },
]

const NOTIFICATION_KEYS = [
  { key: 'notif_job_reminders',     label: 'Job reminders',          desc: 'Remind staff 1 hour before each job' },
  { key: 'notif_invoice_due',       label: 'Invoice due alerts',     desc: 'Alert when an invoice becomes overdue' },
  { key: 'notif_new_quote',         label: 'New quote notifications', desc: 'Notify on incoming quote request' },
  { key: 'notif_daily_report',      label: 'Daily report reminder',  desc: 'Remind drivers to submit end-of-day report' },
  { key: 'notif_payment_received',  label: 'Payment received',       desc: 'Notify when payment is recorded' },
]

export function SettingsClient({ settings: initial }: { settings: Record<string, string> }) {
  const { lang, setLang } = useLanguageStore()
  const [tab, setTab] = useState('general')
  const [settings, setSettings] = useState<Record<string, string>>({
    currency:    'MYR',
    date_format: 'DD/MM/YYYY',
    // notification defaults (true unless explicitly false)
    notif_job_reminders:    'true',
    notif_invoice_due:      'true',
    notif_new_quote:        'false',
    notif_daily_report:     'true',
    notif_payment_received: 'true',
    ...initial,
  })
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState('')

  function showToast(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  function setSetting(key: string, value: string) {
    setSettings(s => ({ ...s, [key]: value }))
  }

  async function saveSettings(extraKeys?: string[]) {
    setSaving(true)
    try {
      // Build payload — either targeted keys or everything
      const payload: Record<string, string> = extraKeys
        ? Object.fromEntries(extraKeys.map(k => [k, settings[k] ?? '']))
        : settings

      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!res.ok) throw new Error('Failed')
      showToast(lang === 'zh' ? '已保存 ✓' : 'Saved ✓')
    } catch (err) {
      console.error(err)
      showToast(lang === 'zh' ? '保存失败' : 'Save failed')
    }
    setSaving(false)
  }

  const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] transition-colors'
  const SaveBtn = ({ keys }: { keys?: string[] }) => (
    <button
      type="button"
      onClick={() => saveSettings(keys)}
      disabled={saving}
      className="px-5 py-2 bg-[#0F4C5C] text-white text-sm font-semibold rounded-lg hover:bg-[#1a6b80] transition-colors disabled:opacity-60">
      {saving ? (lang === 'zh' ? '保存中...' : 'Saving...') : (lang === 'zh' ? '保存更改' : 'Save Changes')}
    </button>
  )

  return (
    <div>
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 lg:bottom-6 right-4 z-[200] bg-green-600 text-white text-sm font-medium px-4 py-2.5 rounded-xl shadow-lg">
          {toast}
        </div>
      )}

      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl lg:text-2xl font-bold">{t('settings', lang)}</h1>
      </div>

      <div className="grid lg:grid-cols-[200px_1fr] gap-4">
        {/* Tab nav */}
        <div className="bg-white rounded-xl shadow-sm p-2 h-fit">
          {TABS.map(tb => (
            <button
              key={tb.key}
              onClick={() => setTab(tb.key)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium text-left transition-all mb-0.5 ${
                tab === tb.key ? 'bg-[#0F4C5C] text-white' : 'text-gray-700 hover:bg-gray-100'
              }`}>
              <span>{tb.icon}</span>{tb.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="bg-white rounded-xl shadow-sm p-5">

          {/* ── GENERAL ── */}
          {tab === 'general' && (
            <div className="space-y-6 max-w-md">
              {/* Language */}
              <div>
                <h3 className="text-sm font-semibold mb-3 pb-2 border-b border-gray-100">
                  Language / 语言
                </h3>
                <div className="flex gap-3">
                  {(['en', 'zh'] as const).map(l => (
                    <button
                      key={l}
                      onClick={() => {
                        setLang(l)
                        setSetting('language', l)
                      }}
                      className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${
                        lang === l ? 'bg-[#0F4C5C] text-white border-[#0F4C5C]' : 'border-gray-200 hover:border-[#0F4C5C]'
                      }`}>
                      {l === 'en' ? '🇬🇧 English' : '🇨🇳 中文'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Currency */}
              <div>
                <h3 className="text-sm font-semibold mb-3 pb-2 border-b border-gray-100">Currency</h3>
                <select
                  value={settings.currency ?? 'MYR'}
                  onChange={e => setSetting('currency', e.target.value)}
                  className={inputCls}>
                  <option value="MYR">MYR (RM)</option>
                  <option value="USD">USD ($)</option>
                  <option value="SGD">SGD (S$)</option>
                  <option value="IDR">IDR (Rp)</option>
                </select>
              </div>

              {/* Date format */}
              <div>
                <h3 className="text-sm font-semibold mb-3 pb-2 border-b border-gray-100">Date Format</h3>
                <select
                  value={settings.date_format ?? 'DD/MM/YYYY'}
                  onChange={e => setSetting('date_format', e.target.value)}
                  className={inputCls}>
                  <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                  <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                  <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                </select>
              </div>

              <SaveBtn keys={['language', 'currency', 'date_format']} />
            </div>
          )}

          {/* ── COMPANY ── */}
          {tab === 'company' && (
            <div className="space-y-4 max-w-md">
              <h3 className="text-sm font-semibold pb-2 border-b border-gray-100">
                {lang === 'zh' ? '公司信息' : 'Company Information'}
              </h3>

              {[
                { key: 'company_name',    label: lang === 'zh' ? '公司名称' : 'Company Name',          placeholder: 'CleanPro Services' },
                { key: 'company_phone',   label: lang === 'zh' ? '联系电话' : 'Phone Number',           placeholder: '+60 12-345 6789' },
                { key: 'company_email',   label: lang === 'zh' ? '电子邮件' : 'Email Address',          placeholder: 'info@cleanpro.com' },
                { key: 'company_website', label: lang === 'zh' ? '网站' : 'Website',                    placeholder: 'https://cleanpro.com' },
                { key: 'company_ssm',     label: lang === 'zh' ? '注册编号 (SSM)' : 'SSM / Reg. No.',  placeholder: 'SA0012345-X' },
              ].map(f => (
                <div key={f.key}>
                  <label className="block text-xs font-medium text-gray-600 mb-1.5">{f.label}</label>
                  <input
                    value={settings[f.key] ?? ''}
                    onChange={e => setSetting(f.key, e.target.value)}
                    placeholder={f.placeholder}
                    className={inputCls}
                  />
                </div>
              ))}

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">
                  {lang === 'zh' ? '公司地址' : 'Company Address'}
                </label>
                <textarea
                  rows={3}
                  value={settings.company_address ?? ''}
                  onChange={e => setSetting('company_address', e.target.value)}
                  placeholder="No. 1, Jalan Klang Lama..."
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1.5">
                  {lang === 'zh' ? '发票备注 (显示在所有发票底部)' : 'Invoice Footer Note'}
                </label>
                <textarea
                  rows={2}
                  value={settings.invoice_footer ?? ''}
                  onChange={e => setSetting('invoice_footer', e.target.value)}
                  placeholder="Payment terms, bank account details..."
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:border-[#0F4C5C] resize-none transition-colors"
                />
              </div>

              <SaveBtn keys={['company_name','company_phone','company_email','company_website','company_ssm','company_address','invoice_footer']} />
            </div>
          )}

          {/* ── NOTIFICATIONS ── */}
          {tab === 'notifications' && (
            <div className="max-w-md">
              <h3 className="text-sm font-semibold pb-2 border-b border-gray-100 mb-4">
                {lang === 'zh' ? '通知设置' : 'Notification Preferences'}
              </h3>
              <div className="space-y-0">
                {NOTIFICATION_KEYS.map(n => (
                  <div key={n.key} className="flex items-center justify-between py-3.5 border-b border-gray-100 last:border-0">
                    <div>
                      <p className="text-sm font-medium">{n.label}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{n.desc}</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer ml-4 flex-shrink-0">
                      <input
                        type="checkbox"
                        checked={settings[n.key] !== 'false'}
                        onChange={e => setSetting(n.key, e.target.checked ? 'true' : 'false')}
                        className="sr-only peer"
                      />
                      <div className="w-10 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer
                        peer-checked:after:translate-x-full peer-checked:after:border-white
                        after:content-[''] after:absolute after:top-[2px] after:left-[2px]
                        after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all
                        peer-checked:bg-[#0F4C5C]" />
                    </label>
                  </div>
                ))}
              </div>
              <div className="mt-5">
                <SaveBtn keys={NOTIFICATION_KEYS.map(n => n.key)} />
              </div>
            </div>
          )}

          {/* ── USERS ── */}
          {tab === 'users' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold">
                  {lang === 'zh' ? '用户访问控制' : 'User Access Control'}
                </h3>
                <button className="px-3 py-1.5 text-xs border border-[#0F4C5C] text-[#0F4C5C] rounded-lg hover:bg-[#0F4C5C] hover:text-white transition-colors">
                  + {lang === 'zh' ? '邀请用户' : 'Invite User'}
                </button>
              </div>
              <table className="w-full data-table">
                <thead>
                  <tr>
                    <th>{lang === 'zh' ? '用户' : 'User'}</th>
                    <th>{lang === 'zh' ? '角色' : 'Role'}</th>
                    <th>{lang === 'zh' ? '访问级别' : 'Access Level'}</th>
                    <th>{lang === 'zh' ? '操作' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { name: 'Admin',          email: 'admin@cleanpro.com', role: 'admin',      badge: 'badge-purple', access: 'Full access to all modules' },
                    { name: 'Kay (Supervisor)', email: 'kay@cleanpro.com', role: 'supervisor', badge: 'badge-blue',   access: 'Schedule, Reports, Clients' },
                    { name: 'Drivers / Staff', email: '—',                 role: 'staff',      badge: 'badge-green',  access: 'Daily Report only' },
                  ].map(u => (
                    <tr key={u.name}>
                      <td>
                        <div className="font-medium text-sm">{u.name}</div>
                        <div className="text-xs text-gray-400">{u.email}</div>
                      </td>
                      <td><span className={`badge ${u.badge}`}>{u.role}</span></td>
                      <td className="text-sm text-gray-600">{u.access}</td>
                      <td>
                        <button className="text-xs px-2 py-1 border border-gray-200 rounded hover:border-[#0F4C5C] transition-colors">
                          ✏️
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="text-xs text-gray-400 mt-4">
                {lang === 'zh'
                  ? '用户管理需要管理员权限。更改将在下次登录后生效。'
                  : 'User management requires admin access. Changes take effect on next login.'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
